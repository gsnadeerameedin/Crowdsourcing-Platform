@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="col">
            <div class="row">

                <div class="col">
                    <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto" class="p-0"
                        style="margin-left: -25px" />
                </div>

                <div class="container-fluid mt-3 row fs-5">
                    <span style="font-weight: lighter"> Make cyberspace a better place while making money in the
                        Sinhala-speaking microtask platform in four steps.</span>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="row" style="margin-top: -40px">
                <div class="col">
                    <img src="{{ asset('images/STEP 1.png') }}" width="320px" height="auto" class="p-0"
                        style="margin-left: 100px" />
                    <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                        style="margin-left: -130px" />


                    <img src="{{ asset('images/STEP 2Y.png') }}" width="320px" height="auto" class="p-0"
                        style="margin-left: -130px" />
                    <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                        style="margin-left: -130px;" />


                    <img src="{{ asset('images/STEP 3Y.png') }}" width="320px" height="auto" class="p-0"
                        style="margin-left: -130px" />
                    <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                        style="margin-left: -130px;" />


                    <img src="{{ asset('images/STEP 4Y.png') }}" width="320px" height="auto" class="p-0"
                        style="margin-left: -130px" />
                </div>
            </div>
            <div class="col fw-bold" style="margin-top: -100px;margin-left: 220px">
                <span>Get Started</span>
                <span style="margin-left: 120px">Create Your Profile</span>
                <span style="margin-left: 110px">Check Your Fit</span>
                <span style="margin-left: 110px">Start the Journey</span>
            </div>
            <div class="col">
                <div class="mt-3" style="margin-left: 165px">
                    <a href="{{ route('create_profile') }}">
                        <button type="button" class="btn btn btn-lg rounded-0 mt-4"
                            style="background-color: #972F15;color: white;margin-left: 800px">Get Started
                        </button>
                    </a>
                </div>
            </div>
            <div class="col" style="margin-left: 800px;text-align: center">

            </div>

        </div>
    </div>
@endsection
