@extends('layouts.app')

@section('content')
    <style>
        hr.spaceline {
            border: 1px solid red;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }

        li {
            float: left;
        }

        #ll li a {
            display: block;
            color: #972F15;
            text-align: center;
            font-weight: bold;
            text-decoration: none;
            margin-left: 80px;
            text-transform: uppercase;
        }

        li a:hover {
            background-color: #FFFFFF;
        }
    </style>

    <div class="container">
        <div>
            <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto" class="p-0"
                 style="margin-left: -25px"/>
            <ul id="ll">
                <li><a href="#overview" style="margin-left: 200px">OVERVIEW</a>
                <li><a href="#features">Features</a>
                <li><a href="#rewards">REWARDS</a>
                <li><a href="#contact">CONTACT US</a>
            </ul>
        </div>
        <hr class="spaceline">

        <div class="row justify-content-center" id="overview">
            <div class="col">
                <div class="row">

                    <div class="col">
                        <img src="{{ asset('images/im3.jpg') }}" width="220px" height="auto" class="p-0"
                             style="margin-left:0px"/>
                    </div>
                    <div class="col" style="margin-top: 25px">
                        <span class="h1 fw-semibold" style="color:#972F15;margin-left:-50px;">Hate Speech
                            Identification</span>
                        <br>
                        <span class="h1" style="color:#972F15;">වෛරී ප්‍රකාශ හඳුනාගැනීම</span>
                    </div>

                    <div class="col">
                        <div class="mt-3" style="margin-left: 165px">
                            <div id="btnNextPost">
                                <button
                                    style="background-color: #972F15;color: white;margin-left: 800px"
                                    class="btn btn btn-lg rounded-0 mt-4"
                                    id="nextPost" onclick="nextPost()">
                                    Next Post&nbsp;&nbsp;>>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="mt-3" style="margin-left: 165px">
                            <button type="button" class="btn btn btn-lg rounded-0 mt-4"
                                    style="background-color: #972F15;color: white;margin-left: 800px"
                                    id="btnNext">Next&nbsp;&nbsp;>>
                            </button>
                        </div>
                        <div class="mt-3" style="margin-left: 165px">
                            <button onclick="saveComment()" type="button" class="btn btn btn-lg rounded-0 mt-4"
                                    style="background-color: #972F15;color: white;margin-left: 800px"
                                    id="btnSave">Save
                            </button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col mt-xl-5">
                <span class="h4 fw-semibold" style="color:#972F15;margin-left:-50px;">Post Caption / Comment</span>
                <br>
            </div>
            <div class="mt-4 ">
                <textarea class="form-control border border-5" id="comment" rows="8"></textarea>
            </div>
        </div>

        <div class="row">
            <div class="col mt-xl-5">
                <span class="h4 fw-semibold" style="color:#972F15;margin-left:-50px;">Analyze Content / අන්තර්ගත
                    විශ්ලේෂණය</span>
                <br>

                <div class="row fs-5 " style="width: 400px">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="AC" id="AC1" value="AC1">
                        <label class="form-check-label" for="AC1">
                            වෛරී ප්‍රකාශ අඩංගු වේ.
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="AC" id="AC2" value="AC2">
                        <label class="form-check-label" for="AC2">
                            වෛරී ප්‍රකාශ අඩංගු නොවේ.
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="AC" id="AC3" value="AC3">
                        <label class="form-check-label" for="AC3">
                            වෛරී ප්‍රකාශ අඩංගුවේ දැයි කිව නොහැක.
                        </label>

                    </div>
                </div>
            </div>
            <div class="col" style="margin-left: 30px">
                <div class="col mt-xl-5">
                    <span class="h4 fw-semibold" style="color:#972F15;margin-left:30px;">Hate Speech Detection / වෛරී කථන
                        හඳුනා ගැනීමේ</span>
                    <br>
                </div>

                <div class="row fs-5 " style="width: 400px; margin-left: 30px">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="HD1" value="HD1">
                        <label class="form-check-label" for="flexRadioDefault1">
                            Direct incitement/Threat of violence <br> සෘජු උසිගැන්වීම් / ප්‍රචණ්ඩත්වය සම්බන්ධව තර්ජන
                            අඩංගු වේ
                        </label>

                    </div>
                    <div class="form-check mt-4">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HD2">
                        <label class="form-check-label" for="flexRadioDefault1">
                            Glorification of physical violence / ශාරීරික හිංසනය ප්‍රශංසා කිරීම් අඩු වෙයි
                        </label>

                    </div>
                    <div class="form-check mt-4">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HD3">
                        <label class="form-check-label" for="flexRadioDefault1">
                            Incitement to discrimination/hate / අසාධාරණ සහ අගතිගාමීව ලෙස සැලකීමට හෝ වෛර කිරීමට පෙළඹවීමකි
                        </label>

                    </div>
                    <div class="form-check mt-4">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HD4">
                        <label class="form-check-label" for="flexRadioDefault1">
                            An offense to the collective sensitivity / සමූහයකට අපහාස කිරීම හෝ ප්‍රකෝපනය කිරීම
                        </label>

                    </div>
                    <div class="form-check mt-4">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HD5">
                        <label class="form-check-label" for="flexRadioDefault1">
                            other / වෙනත්
                        </label>

                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col mt-xl-5">
                <span class="h4 fw-semibold" style="color:#972F15;margin-left:-50px;">Select the Hate Categories / වෛරී
                    කාණ්ඩය තෝරන්න</span>
                <br>

                <div class="row fs-5 mt-4" style="width: 400px">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="HC1" value="HC1">
                        <label class="form-check-label" for="flexRadioDefault1">
                            ජාතියක්‌/ ජාතිවාදී
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="HC2" value="HC2">
                        <label class="form-check-label" for="flexRadioDefault1">
                            ආගම්‌ / ආගම්වාදී
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC3">
                        <label class="form-check-label" for="flexRadioDefault1">
                            පුරවැසිභාවය /වාර්ගිකත්වය
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC4">
                        <label class="form-check-label" for="flexRadioDefault1">
                            ලිංගික දිශානනිය
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC5">
                        <label class="form-check-label" for="flexRadioDefault1">
                            ආබාධින තත්වය
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC6">
                        <label class="form-check-label" for="flexRadioDefault1">
                            රෝග වලට ගොදුරු වූ
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC7">
                        <label class="form-check-label" for="flexRadioDefault1">
                            සංක්රමණික
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC8">
                        <label class="form-check-label" for="flexRadioDefault1">
                            වෘත්තිය
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC9">
                        <label class="form-check-label" for="flexRadioDefault1">
                            කුලය / පන්තිය
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC10">
                        <label class="form-check-label" for="flexRadioDefault1">
                            දේශපාලනික
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC11">
                        <label class="form-check-label" for="flexRadioDefault1">
                            පලානක වැසියන්‌
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC12">
                        <label class="form-check-label" for="flexRadioDefault1">
                            ස්ත්‍රී පුරුෂ භාවය
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC13">
                        <label class="form-check-label" for="flexRadioDefault1">
                            ච්යාපාර වෙනන්‌ සමාජ කණ්ඩායම්‌
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC14">
                        <label class="form-check-label" for="flexRadioDefault1">
                            පුද්ගලයකු
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC15">
                        <label class="form-check-label" for="flexRadioDefault1">
                            යම්‌ පුද්ගලයකුට සම්බන්ද්ධ පුද්ගලයන්‌, ඥානින්‌ හැසිරීම
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC16">
                        <label class="form-check-label" for="flexRadioDefault1">
                            භෞනික ලක්ෂණ/ ශරීර ලක්ෂණ
                        </label>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="flexRadioDefault" id="flexRadioDefault1" value="HC17">
                        <label class="form-check-label" for="flexRadioDefault1">
                            වෙනත්
                        </label>
                    </div>
                </div>
            </div>
            <div class="col" style="margin-left:-80px">
                <div class="col mt-xl-5">
                    <span class="h4 fw-semibold" style="color:#972F15;margin-left:30px;">Enter the hate targets/ හඳුනාගත්
                        වෛරී ඉලක්ක ඇතුලත් කරන්න</span>
                    <br>
                </div>

                <div class="row fs-5 mt-4" style="width: 400px; margin-left: 30px">
                    <div class="form-check">
                        <input class="form-control" type="text" placeholder="Ex උදාහරණ">

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        var post_comments = [];
        let commentTexts = [];
        var nextNumber = 1;
        var post_id;
        var comment_id;
        var comment_text;

        function nextPost() {
            commentTexts.length = 0;
            nextNumber = 1;
            const currentTimestamp = new Date().toISOString()
            fetch(`http://54.244.163.184:8060/fb-json-generator/api/json?timestamp=${currentTimestamp}`)
                .then(response => response.json())
                .then(data => {
                    post_comments = data.comments
                    nextComment()
                    post_id = data.top_level_post_id;
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        // Get the form and file field
        let nxtBtn = document.querySelector('#btnNext');

        function nextComment(event) {
            const comments = post_comments;

            for (const comment of comments) {
                commentTexts.push(
                    {
                        id: comment.comment_id,
                        text: comment.commentText ? comment.commentText : "",
                    }
                );
            }
            document.getElementById("comment").textContent = commentTexts[0]?.text === undefined || commentTexts[0]?.text === null ? "no comment found!" : commentTexts[0]?.text;
            // event.preventDefault();
        }
        nxtBtn.addEventListener('click', onClickNext);

        function onClickNext() {
            event.preventDefault();

            if (nextNumber != commentTexts.length) {
                document.getElementById("comment").textContent = commentTexts[nextNumber]?.text === undefined || commentTexts[nextNumber]?.text === null ? "no comment found!" : commentTexts[nextNumber]?.text;
                comment_id = commentTexts[nextNumber]?.id
                comment_text = commentTexts[nextNumber]?.text
                nextNumber++;
            } else if (nextNumber === commentTexts.length) {
                console.log('no comment in this post')
            } else {
                console.log('comment over')
            }
        }

        //save comment data
        function saveComment() {

            // Get radio buttons by their name attribute
            const radioButtons = document.getElementsByName('AC');
            let ACselectedValue;
            for (let i = 0; i < radioButtons.length; i++) {
                if (radioButtons[i].checked) {
                    ACselectedValue = radioButtons[i].value;
                    break;
                }
            }

            // Get checkboxes by their name attribute
            const checkboxes = document.getElementsByName('flexRadioDefault');

            const selectedValues = [];
            for (let i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].checked) {
                    selectedValues.push(checkboxes[i].value);
                }
            }

            const savedEmail = localStorage.getItem('email');
            $.ajax({
                url: "{{ route('save_comment_data') }}",
                type: 'GET',
                data: {
                    'email':savedEmail,
                    'comment_id': comment_id,
                    'post_id': post_id,
                    'ac': ACselectedValue,
                    'categorization': selectedValues,
                },
            })
        }

    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
