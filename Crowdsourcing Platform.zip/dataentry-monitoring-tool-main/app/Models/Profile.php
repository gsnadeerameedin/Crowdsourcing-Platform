<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Profile extends Model
{
    use HasFactory;

    protected $fillable = [
        'firstname',
        'surname',
        'email',
        'mobile_two',
        'mobile_one',
        'civil_status',
        'religion',
        'gender',
        'birthday',
        'nic',
        'education',
        'nature_of_emp',
        'language',
        'address',
        'monetary_rewards',
        'top_up_mobile',
        'account_name',
        'bank',
        'branch',
        'acc_number',
        'preferred_contact',
        'agree'
    ];
}
