<?php

use App\Http\Controllers\Auth\AuthController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Auth::routes();

Route::group(['middleware' => ['auth:sanctum']], function () {

    Route::post('logout', [AuthController::class, 'logout']);
});

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/workWithUs', [App\Http\Controllers\WorkWithUsController::class, 'index'])->name('workWithUs');
Route::get('/create_profile', [App\Http\Controllers\ProfileController::class, 'index'])->name('create_profile');
Route::post('/add_profile', [App\Http\Controllers\ProfileController::class, 'addProfile'])->name('add_profile');
Route::get('/checkYourFit', [App\Http\Controllers\ProfileController::class, 'checkYourFit'])->name('checkYourFit');
Route::get('/labelling_task_type', [App\Http\Controllers\ProfileController::class, 'labelling_task_type_page'])->name('labelling_task_type');
Route::get('/hate_speech_identification', [App\Http\Controllers\ProfileController::class, 'hate_speech_identification_page'])->name('hate_speech_identification');
Route::get('/hate_corpus_identification', [App\Http\Controllers\ProfileController::class, 'hate_corpus_identification_page'])->name('hate_corpus_identification');
Route::get('/save_comment_data', [App\Http\Controllers\ProfileController::class, 'saveCommentData'])->name('save_comment_data');
Route::get('/save_correct_answers', [App\Http\Controllers\ProfileController::class, 'saveCorrectAnswer'])->name('save_correct_answers');
Route::get('/save_inappropriate_data', [App\Http\Controllers\ProfileController::class, 'saveInappropriateData'])->name('save_inappropriate_data');

Route::get('register', [AuthController::class, 'register'])->name('register');
Route::get('login', [AuthController::class, 'login'])->name('login');
Route::post('check_login', [AuthController::class, 'checkLogin'])->name('check_login');
