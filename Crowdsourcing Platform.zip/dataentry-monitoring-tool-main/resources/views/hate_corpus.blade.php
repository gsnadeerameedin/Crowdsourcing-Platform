@extends('layouts.app')

@section('content')
<style>
    hr.spaceline {
        border: 1px solid red;
    }

    ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }

    li {
        float: left;
    }

    #ll li a {
        display: block;
        color: #972F15;
        text-align: center;
        font-weight: bold;
        text-decoration: none;
        margin-left: 80px;
        text-transform: uppercase;
    }

    li a:hover {
        background-color: #FFFFFF;
    }
</style>

<div class="container">

    <div>
        <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto" class="p-0"
             style="margin-left: -25px"/>
        <ul id="ll">
            <li><a href="#overview" style="margin-left: 200px">OVERVIEW</a>
            <li><a href="#features">Features</a>
            <li><a href="#rewards">REWARDS</a>
            <li><a href="#contact">CONTACT US</a>
        </ul>
    </div>
    <hr class="spaceline">


    <div class="row justify-content-center" id="overview">
        <div class="col">
            <div class="row">

                <div class="col">
                    <img src="{{ asset('images/im3.jpg') }}" width="220px" height="auto" class="p-0"
                         style="margin-left:0px"/>
                </div>
                <div class="col" style="margin-top: 25px">
                        <span class="h1 fw-semibold" style="color:#972F15;margin-left:-50px;">Hate Corpus
                            Identification</span>
                    <br>
                    <span class="h1" style="color:#972F15;">ලිඛිත වෛරී ප්‍රකාශ හඳුනාගැනීම</span>
                </div>


{{--                <div class="col">--}}
{{--                    <div class="mt-3" style="margin-left: 165px">--}}
{{--                        <form id="upload" class="mt-4" style="margin-left: 800px">--}}
{{--                            <input type="file" id="file" accept=".json">--}}
{{--                            <button>Upload</button>--}}
{{--                        </form>--}}
{{--                    </div>--}}
{{--                </div>--}}
                <div class="col">
                    <div class="mt-3" style="margin-left: 165px">
                        <div id="btnNextPost">
                            <button
                                style="background-color: #972F15;color: white;margin-left: 800px"
                                class="btn btn btn-lg rounded-0 mt-4"
                                id="nextPost" onclick="nextPost()">
                                Next Post&nbsp;&nbsp;>>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="mt-3" style="margin-left: 165px">
                        <a href="{{ route('labelling_task_type') }}">
                            <button type="button" class="btn btn btn-lg rounded-0 mt-4"
                                    style="background-color: #972F15;color: white;margin-left: 800px"
                                    id="btnNext">Next&nbsp;&nbsp;>>
                            </button>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col mt-xl-5">
            <span class="h4 fw-semibold" style="color:#972F15;margin-left:-50px;">Caption</span>
            <br>
        </div>
        <div class="mt-4 ">
            <textarea class="form-control border border-5" id="comment" rows="8"></textarea>
        </div>
    </div>

    <div class="row">
        <div class="col mt-xl-5">
                <span class="h4 fw-semibold" style="color:#972F15;">මෙහි වෛරී
                    ප්‍රකාශ අඩංගු නොවේ.</span>
            <button type="button" class="btn btn btn-lg rounded-0"
                    style="background-color: #972F15;color: white;margin-left: 800px"
                    id="btnSave">Save Hate Corpus
            </button>
        </div>
    </div>

    <div id="myPopup" class="popup"
         style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
        <div class="popup-content"
             style="background-color: white; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 50%;">
            <span class="close" style="color: #aaa; float: right; font-size: 28px; font-weight: bold;">&times;</span>
            <p><b>Data Saved!</b></p>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-6">
           <span class="h4 fw-semibold" style="color:#972F15;">Word As Tokens / වචන සංකේත
               ලෙස ප්‍රකාශනය</span>
            <textarea class="form-control border border-5 mt-4" id="tokens" rows="24"></textarea>
        </div>
        <div class="col-6">
            <span class="h4 fw-semibold" style="Òcolor:#972F15;">Hate Corpus Identification / වෛරී පාඨ හදුනාගැනීම</span>
            <div class="mt-4">
                <span>If there are inappropriate words and phrases to publish (defamatory and obscene content)</span>
                <br>
                <span>පළ කිරීමට නුසුදුසු වචන සහ වාක්‍ය ඛණ්ඩ තිබේ නම් (අපහාසාත්මක සහ අසභ්‍ය අන්තර්ගතය)</span>
                <textarea class="form-control border border-5 mt-4" id="inappropriate" rows="6"></textarea>
            </div>

            <div class="mt-3">
                <span>Words and phrases to identify hate targets</span>
                <br>
                <span>වෛරී ඉලක්ක හඳුනා ගැනීමට වචන සහ වාක්‍ය ඛණ්ඩ</span>
                <textarea class="form-control border border-5 mt-4" id="hateTargets" rows="6"></textarea>
            </div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script>

    //get post and iterate comment
    var post_comments = [];
    const commentTexts = [];
    var nextNumber = 0;

    function nextPost() {
        commentTexts.length = 0
        nextNumber = 0
        const currentTimestamp = new Date().toISOString()
        fetch(`http://54.244.163.184:8060/fb-json-generator/api/json?timestamp=${currentTimestamp}`)
            .then(response => response.json())
            .then(data => {
                post_comments = data.comments
                nextComment()
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }

    // Get the form and file field
    let nxtBtn = document.querySelector('#btnNext');

    function nextComment(event) {
        document.getElementById("inappropriate").textContent = '';
        document.getElementById("hateTargets").textContent = '';

        const comments = post_comments;
        for (const comment of comments) {
            commentTexts.push(comment.commentText ? comment.commentText : "");
        }

        document.getElementById("comment").textContent = commentTexts[0];
        toeknize(commentTexts[0]);
        // event.preventDefault();
    }

    nxtBtn.addEventListener('click', onClickNext);

    function onClickNext() {
        event.preventDefault();
        if (nextNumber != commentTexts.length) {
            document.getElementById("comment").textContent = commentTexts[nextNumber];
            toeknize(commentTexts[nextNumber]);
            nextNumber++;
        } else if (nextNumber === commentTexts.length) {
            console.log('comments over')
        } else {
            nextNumber = 0;
            document.getElementById("comment").textContent = commentTexts[nextNumber];
            toeknize(commentTexts[nextNumber]);
            nextNumber++;
        }
    }

    function toeknize(word) {
        document.getElementById("tokens").value = word.split(" ").join("   ");
    }

    //save Hate Corpus Identification data
    const btnSave = document.querySelector('#btnSave');
    const savedEmail = localStorage.getItem('email');
    function saveInappropriateData() {
        const inappropriateText = document.querySelector('#inappropriate').value;
        const hateTargetText = document.querySelector('#hateTargets').value;

        if (inappropriateText || hateTargetText !== '') {
            $.ajax({
                url: "{{ route('save_inappropriate_data') }}",
                type: 'GET',
                data: {
                    'email':savedEmail,
                    'inappropriate': inappropriateText,
                    'hateTarget': hateTargetText,
                },
            })
        }

    }

    btnSave.addEventListener('click', saveInappropriateData);

    //popup
    const myButton = document.getElementById("btnSave");
    const myPopup = document.getElementById("myPopup");
    const closeBtn = myPopup.querySelector(".close");

    myButton.addEventListener("click", function () {
        const inappropriateText = document.querySelector('#inappropriate').value;
        const hateTargetText = document.querySelector('#hateTargets').value;

        if (inappropriateText || hateTargetText !== '') {
            myPopup.style.display = "block";
        }
    });

    closeBtn.addEventListener("click", function () {
        myPopup.style.display = "none";
    });

    window.addEventListener("click", function (event) {
        if (event.target == myPopup) {
            myPopup.style.display = "none";
        }
    });

</script>
@endsection
