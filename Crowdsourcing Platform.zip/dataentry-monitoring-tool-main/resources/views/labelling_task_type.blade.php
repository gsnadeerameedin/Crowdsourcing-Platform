@extends('layouts.app')

@section('content')

<style>
    hr.spaceline {
        border: 1px solid red;
    }

    ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }

    li {
        float: left;
    }

    #ll li a {
        display: block;
        color: #972F15;
        text-align: center;
        font-weight: bold;
        text-decoration: none;
        margin-left: 80px;
        text-transform: uppercase;
    }

    li a:hover {
        background-color: #FFFFFF;
    }
</style>

<div class="container">

    <div>
        <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto"
             class="p-0" style="margin-left: -25px"/>
        <ul id="ll">
            <li><a href="#overview" style="margin-left: 200px">OVERVIEW</a>
            <li><a href="#features">Features</a>
            <li><a href="#rewards">REWARDS</a>
            <li><a href="#contact">CONTACT US</a>
        </ul>
    </div>
    <hr class="spaceline">


    <div class="row justify-content-center" id="overview">
        <div class="col">
            <div class="row">

                <div class="col">

                </div>
                <div class="col" style="margin-top: 25px">
                        <span class="h1 fw-semibold"
                              style="color:#972F15;margin-left: 200px;">LABELLING TASK TYPES</span>
                </div>

            </div>
        </div>
    </div>


    <div class="card-group mt-5">
        <div class="card m-2 h-25">
            <img src="{{ asset('images/im1.jpg') }}" class="card-img-top" alt="..."
                 style="height:180px;object-fit: cover;">
            <div class="card-body mt-5">
                <h5 class="card-title fw-bold text-center">Language and Inappropriate Content Identification</h5>
            </div>

        </div>
        <div class="card m-2 h-25">
            <img src="{{ asset('images/im2.png') }}" class="card-img-top" alt="..."
                 style="height:180px;object-fit: cover;">
            <div class="card-body mt-5">
                <h5 class="card-title fw-bold text-center">Image Text Identification</h5>
            </div>

        </div>
        <div class="card m-2 h-25">
            <a href="{{ route('hate_speech_identification') }}">

                <img src="{{ asset('images/im3.jpg') }}" class="card-img-top" alt="..."
                     style="height:180px;object-fit: cover;">
            </a>

            <div class="card-body mt-5">
                <h5 class="card-title fw-bold text-center">Hate Speech Identification</h5>
            </div>

        </div>

    </div>
    <div class="card-group mt-5">
        <div class="card m-2 h-25">
            <img src="{{ asset('images/im4.png') }}" class="card-img-top" alt="..."
                 style="height:180px;object-fit: cover;">
            <div class="card-body mt-5">
                <h5 class="card-title fw-bold text-center">Hate Speech Content Propagator Identification</h5>
            </div>

        </div>
        <div class="card m-2 h-25">
            <img src="{{ asset('images/im5.png') }}" class="card-img-top" alt="..."
                 style="height:180px;object-fit: cover;">
            <div class="card-body mt-5">
                <h5 class="card-title fw-bold text-center">Sentiment Analysis</h5>
            </div>

        </div>
        <div class="card m-2 h-25">
            <a href="{{ route('hate_corpus_identification') }}">

                <img src="{{ asset('images/im6.png') }}" class="card-img-top" alt="..."
                     style="height:180px;object-fit: cover;">
            </a>

            <div class="card-body mt-5">
                <h5 class="card-title fw-bold text-center">Hate Corpus Generation</h5>
            </div>

        </div>

    </div>


</div>

@endsection
