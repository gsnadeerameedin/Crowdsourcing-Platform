<?php

namespace App\Http\Controllers;

use App\Models\HateCorpus;
use App\Models\HateSpeechIdentification;
use App\Models\Profile;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ProfileController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
//        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view("create_profile", ['age' => "null"]);
    }

    public function checkYourFit()
    {
        return view('start_the_journey');
    }

    public function labelling_task_type_page()
    {
        return view('labelling_task_type');
    }

    public function hate_speech_identification_page()
    {
        return view('hate_speech_identification');
    }

    public function hate_corpus_identification_page()
    {
        return view('hate_corpus');
    }

    public function addProfile(Request $request)
    {

        $firstname = $request->fname;
        $surname = $request->surname;
        $email = $request->email;
        $mobileTwo = $request->mobileTwo;
        $mobileOne = $request->mobileOne;
        $PreferredContact = $request->PreferredContact;
        $CivilStatus = $request->CivilStatus;
        $Gender = $request->Gender;
        $Religion = $request->Religion;
        $Birthday = $request->Birthday;
        $nic = $request->nic;
        $EducationQ = $request->EducationQ;
        $NatureOfEmp = $request->NatureOfEmp;
        $Language = $request->Language;
        $Address = $request->Address;
        $monetaryRewards = $request->monetaryRewards;
        $topUpMobile = $request->topUpMobile;
        $accountName = $request->accountName;
        $Bank = $request->Bank;
        $Branch = $request->Branch;
        $accNumber = $request->accNumber;
        $agree = $request->agree;

        $birthDate = $Birthday;

        $currentDate = date("d-m-Y");

        $age = date_diff(date_create($birthDate), date_create($currentDate));

//        echo "Current age is " . $age->format("%y");

        if ($age->format("%y") < 18) {

            return view("create_profile", ['age' => "Sorry, Your age should be more than 18 to register as a CONTRIBUTOR in the UOM-Crowd
"]);
        } else {
            Profile::create([
                'firstname' => $firstname,
                'surname' => $surname,
                'email' => $email,
                'mobile_two' => $mobileTwo,
                'mobile_one' => $mobileOne,
                'civil_status' => $CivilStatus,
                'religion' => $Religion,
                'gender' => $Gender,
                'birthday' => $Birthday,
                'nic' => $nic,
                'education' => $EducationQ,
                'nature_of_emp' => $NatureOfEmp,
                'language' => $Language,
                'address' => $Address,
                'monetary_rewards' => $monetaryRewards,
                'top_up_mobile' => $topUpMobile,
                'account_name' => $accountName,
                'bank' => $Bank,
                'branch' => $Branch,
                'acc_number' => $accNumber,
                'preferred_contact' => $PreferredContact,
                'agree' => $agree,


            ]);

            return view('check_your_fit');
        }


//        dd($age->format("%y"));


    }

    public function saveCommentData(Request $request)
    {
        $user = User::where('email', '=', $request->email)->get();

        $id = $user[0]->id;

        $user = User::find($id);

        error_log("current user id");
        error_log($user->id);
        $categorization = $request->categorization;

        $hateSpeachIdentification = new HateSpeechIdentification();

        $hateSpeachIdentification->user_id = $user->id;
        $hateSpeachIdentification->comment_id = $request->comment_id;
        $hateSpeachIdentification->post_id = $request->post_id;
        $hateSpeachIdentification->content = $request->ac;

        $hateSpeachIdentification->save();

        foreach ($categorization as $value) {
            DB::table('hate_speech_details')->insert([
                'categorization' => $value,
                'post_id' => $request->post_id,
                'comment_id' => $request->comment_id,
            ]);
        }
    }

    public function saveCorrectAnswer(Request $request)
    {

        $user = User::where('email', '=', $request->email)->get();

        $id = $user[0]->id;

        $user = User::find($id);

        $user->score = $request->correct_answers;

        $user->save();

    }

    public function saveInappropriateData(Request $request)
    {

//        $currentUser = Auth::user()->id;

        $user = User::where('email', '=', $request->email)->get();

        $id = $user[0]->id;

        $user = User::find($id);

        $hateCorpus = new HateCorpus();

        $hateCorpus->user_id = $user->id;
        $hateCorpus->inappropriate = $request->inappropriate;
        $hateCorpus->hateTarget = $request->hateTarget;

        $hateCorpus->save();


    }

}
