@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="col">
            <div class="row">
                <div class="col" style="margin-left: 300px">
                    <span class="h1 fw-semibold" style="color:#972F15;margin-left: 200px;">Create your profile</span>
                </div>
            </div>
        </div>
        @if($age !== "null")
            <div class="alert alert-danger mt-5" role="alert">
                <span>{{$age}}</span>
            </div>
        @endif

        <form action="{{ route('add_profile') }}" method="post" name="form1">
            {{ csrf_field() }}
            <div class="col">
                <div class="row" style="margin-top: -40px; margin-left: -40px">
                    <div class="col">
                        <img src="{{ asset('images/STEP 1Y.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: 160px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -130px"/>


                        <img src="{{ asset('images/STEP 2.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -130px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -130px"/>


                        <img src="{{ asset('images/STEP 3Y.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -130px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -130px"/>


                        <img src="{{ asset('images/STEP 4Y.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -130px"/>
                    </div>
                </div>
                <div class="row">

                    <div class="col fw-bold" style="margin-top: -100px;margin-left: 280px">
                        <span>Get Started</span>
                        <span style="margin-left: 120px">Create Your Profile</span>
                        <span style="margin-left: 110px">Check Your Fit</span>
                        <span style="margin-left: 110px">Start the Journey</span>
                    </div>
                </div>
                <div class="col">
                    <div class="col" style="margin-left: 320px;margin-top: -50px">
                        <span class=" fw-semibold" style="color:#972F15">Please fill out all the fields so that we can
                            process your application in the fastest time possible.</span><br>
                    </div>

                    <div class="col" style="margin-left: 260px; margin-top: 10px">
                        <span class="fw-semibold" style="color:#dc3545">
                            *Confidentiality of personal data : We protect your personal data for as
                            long as we store or use them. We remove all identifying information from
                            any kind of report or research papers and will not provide any means to identify
                            the participants of the platform.
                        </span>
                    </div>

                </div>
                <div class="row">
                    <div class="col mt-5">
                        <span class="fs-5 mt-5" style="font-weight:bold">Personal Information</span>
                    </div>
                    <div class="row">
                        <div class="col mt-4">
                            <span class="p-3">Update profile Pic: </span>
                            <input type="file" id="img" name="img" accept="image/*">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mt-4">
                            <div class="input-group mb-3">
                                <span class="p-3">First Name: </span>
                                <input name="fname" id="fname" type="text" class="form-control" placeholder=""
                                       aria-label="firstname" required>
                                <span class="p-3">Surname: </span>
                                <input name="surname" id="surname" type="text" class="form-control" placeholder=""
                                       aria-label="Surname" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mt-4">
                            <div class="input-group mb-3">
                                <span class="p-3">Email: </span>
                                <input name="email" id="email" type="email" class="form-control" placeholder=""
                                       aria-label="Email" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}" required>
                                <div class="col">
                                    <button type="button" class="btn rounded-0 ms-lg-3"
                                            onclick="ValidateEmail(document.form1.email)"
                                            style="background-color: #972F15;color: white;width: 80px">Verify
                                    </button>
                                    <span class="p-3" style="color: #972F15">Email address will be your username
                                    </span>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mt-4">
                            <div class="input-group w-50">
                                <span class="p-3">Enter a password: </span>
                                <input name="pswd1" type="text" id="password" class="form-control"
                                       placeholder="" aria-label="password" pattern=".{8,}" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3">
                                <span class="p-3">Confirm password:</span>
                                <input type="text" name="pswd2" id="confirm_password" class="form-control"
                                       placeholder="" aria-label="Confirm Password" required oninput="checkPasswordMatch()">
                                <span id="password_match_message" class="invalid-feedback" style="display: none;">Passwords do not match</span>
                            </div>
                        </div>
                        <div class="col">
                            <button type="button" class="btn rounded-0"
                                    onclick="ConfirmPassCheck()"
                                    style="background-color: #972F15;color: white;width: 100px;margin-top: 30px">Verify
                            </button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mt-4">
                            <div class="input-group ">
                                <span class="p-3">Mobile No 1: </span>
                                <input name="mobileOne" id="mobileOne" type="tel" class="form-control"
                                       placeholder="" aria-label="Mobile number" pattern="[0-9]{10}" required>
                            </div>
                        </div>
                        <div class="col">
                            <button type="button" class="btn rounded-0"
                                    onclick="ValidateNumber(document.form1.mobileOne)"
                                    style="background-color: #972F15;color: white;width: 100px;margin-top: 30px">Verify
                            </button>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Mobile No 2:</span>
                                <input name="mobileTwo" id="mobileTwo" type="tel" class="form-control"
                                       placeholder="" aria-label="Mobile number" pattern="[0-9]{10}" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Preferred way to contact:</span>
                                <select id="preferred_way_to_contact" name="PreferredContact" class="form-select"
                                        aria-label="Default select example" required>
                                    <option value ="" selected disabled>Select</option>
                                    <option value="Phone">Phone</option>
                                    <option value="Email">Email</option>
                                    <option value="Any">Any</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Civil Status:</span>
                                <select id="civil_status" name="CivilStatus" class="form-select"
                                        aria-label="Default select example" required>
                                    <option value ="" selected disabled>Select</option>
                                    <option value="Single">Single</option>
                                    <option value="Married">Married</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Gender:</span>
                                <select id="gender" name="Gender" class="form-select"
                                        aria-label="Default select example" required>
                                    <option value ="" selected disabled>Select</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="IPreferNotToReveal">I prefer not to reveal</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Religion:</span>
                                <select id="religion" name="Religion" class="form-select"
                                        aria-label="Default select example" required>
                                    <option value ="" selected disabled>Select</option>
                                    <option value="Buddhist">Buddhist</option>
                                    <option value="Hindu">Hindu</option>
                                    <option value="Islam">Islam</option>
                                    <option value="RomanCatholic">Roman Catholic</option>
                                    <option value="OtherChristian">Other Christian</option>
                                    <option value="Other">Other</option>
                                    <option value="AtheistsorAgnostics">Atheists or Agnostics</option>
                                    <option value="IPreferNotToReveal">I prefer not to reveal</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mt-4">
                            <div class="input-group mb-3" style="width: 1220px">
                                <span class="p-3">Birthday: </span>
                                <input name="Birthday" id="Birthday" type="date" class="form-control"
                                       placeholder="" aria-label="firstname" required>
                                <span class="p-3">NIC: </span>
                                <input name="nic" id="nic" type="nic" class="form-control" placeholder=""
                                       aria-label="NIC" pattern="[0-9]{9}[vVxX]|[0-9]{12}" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Education Qualifications:</span>
                                <select id="education" name="EducationQ" class="form-select"
                                        aria-label="Default select example" required>
                                    <option value ="" selected disabled>Select one</option>
                                    <option value="no formal education">No formal education</option>
                                    <option value="primary">Primary Education</option>
                                    <option value="ordinary level">Ordinary Level(O/L)</option>
                                    <option value="advanced level">Advanced Level(A/L)</option>
                                    <option value="bachelors degree">Bachelor's degree</option>
                                    <option value="masters degree">Master's degree</option>
                                    <option value="doctorate or higher">Doctorate or higher</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Nature of Employment:</span>
                                <select id="employment" name="NatureOfEmp" class="form-select"
                                        aria-label="Default select example" required>
                                    <option value ="" selected disabled>Select</option>
                                    <option value="Self-employed">Self-employed</option>
                                    <option value="Un-employed">Un-employed</option>
                                    <option value="Employed">Employed</option>
                                    <option value="Retired">Retired</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Language Proficiency:</span>
                                <select id="language" name="Language" class="form-select"
                                        aria-label="Default select example" required>
                                    <option value ="" selected disabled>Select</option>
                                    <option value="Sinhala">Sinhala</option>
                                    <option value="Tamil">Tamil</option>
                                    <option value="English">English</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="input-group mt-3" style="width: 625px">
                                    <span class="p-3">Address where you spend time mostly:</span>
                                    <input name="Address" id="Address" type="text" class="form-control"
                                           placeholder="" aria-label="firstname" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mt-5">
                                <span class="fs-5" style="font-weight:bold">Monetary Rewards</span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">How do you like to redeem your monetary rewards:</span>
                                <select id="rewards" name="monetaryRewards" class="form-select"
                                        aria-label="Default select example" required>
                                    <option value ="" selected disabled>Select</option>
                                    <option value="Top_up_mobile">Top up mobile</option>
                                    <option value="Deposit_to_bank">Deposit to bank</option>
                                    <option value="I_do_not_expect_monetary_reward">I do not expect monetary reward
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 1025px">
                                <span class="p-3">Mobile Number that you want to top up with:</span>
                                <input name="topUpMobile" id="topUpMobile" type="text" class="form-control"
                                       placeholder="" aria-label="firstname" required>
                                <div class="col">
                                    <button type="button" class="btn rounded-0 ms-lg-3"
                                            onclick="ValidateNumber(document.form1.topUpMobile)"
                                            style="background-color: #972F15;color: white;width: 80px">Verify
                                    </button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mt-5">
                            <span class="fs-5" style="font-weight:bold">Bank Details</span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Name of the account holder:</span>
                                <input id="accountName" name="accountName" type="text" class="form-control"
                                       placeholder="" aria-label="firstname" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Bank:</span>
                                <select id="banks" name="Bank" class="form-select" aria-label="Default select example" required>
                                    <option value ="" selected disabled>Select one</option>
                                    <option value="amana bank plc ">Amana Bank PLC</option>
                                    <option value="bank of ceylon">Bank of Ceylon</option>
                                    <option value="cargills bank ltd">Cargills Bank Ltd</option>
                                    <option value="citibank, n.a">Citibank, N.A.</option>
                                    <option value="commercial bank of ceylon plc">Commercial Bank of Ceylon PLC.
                                    </option>
                                    <option value="deutsche bank ag">Deutsche Bank AG</option>
                                    <option value="hatton national bank plc">Hatton National Bank PLC</option>
                                    <option value="national development bank plc">National Development Bank PLC</option>
                                    <option value="nations trust bank plc">Nations Trust Bank PLC</option>
                                    <option value="pan asia banking corporation plc">Pan Asia Banking Corporation PLC</option>
                                    <option value="people's bank">People's Bank</option>
                                    <option value="sampath bank plc">Sampath Bank PLC</option>
                                    <option value="seylan bank plc.">Seylan Bank PLC.</option>
                                    <option value="standard chartered bank">Standard Chartered Bank</option>
                                    <option value="the hongkong & shanghai banking">The Hongkong & Shanghai Banking</option>
                                    <option value="corporation ltd (hsbc)">Corporation Ltd (HSBC)</option>
                                    <option value="union bank of colombo plc">Union Bank of Colombo PLC</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Branch:</span>
                                <input name="Branch" id="Branch" type="text" class="form-control" placeholder=""
                                       aria-label="firstname" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 625px">
                                <span class="p-3">Account Number:</span>
                                <input name="accNumber" id="accNumber" type="text" class="form-control"
                                       placeholder="" aria-label="firstname" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="input-group mt-3" style="width: 1025px">
                                <span class="p-3">Agreement:</span>
                                <div class="card">
                                    <span style="background-color: #FCEED1">The tasks provided herein are the
                                        user-generated content on the social media platforms such as Facebook YouTube and
                                        Twitter. The contents may contain harmful or inappropriate contents. You are free to
                                        quit at any stage of the process if you get uneasy
                                        by viewing such posts,
                                        <br><b>Worker Terms</b></br>
                                        <br>Worker Terms and Conditions</br>
                                        <br>
                                        <span style="color: black;">1.&nbsp;&nbsp;&nbsp;Confidentiality</span>
                                        <p style="display: inline; color: red;">
                                        <b>of personal data - We protect your personal data for as
                                            long as we store or use them. We remove all identifying information from any
                                            kind of report or research papers and will not provide any means to identify
                                            the participants of the platform.</b>
                                        </p>
                                        <br>
                                        <br>
                                        2. &nbsp;&nbsp;&nbsp;Professional Conduct - You are expected to conduct yourself and
                                        communicate with UOM.Crowd and other workers in a professional manner. Obscene,
                                        lewd, filthy, abusive, threatening and/or harassing behaviour or language geared
                                        toward our team members, partners, affiliates or any members of aur workforce team
                                        will not be tolerated
                                        <br>
                                        <br>
                                        3. &nbsp;&nbsp;&nbsp;Privacy - You are not permitted to give personally identifiable
                                        information of others without their expressed and written consent This includes, but
                                        is not limited to: last names, physical or email addresses, worker IDs and phone
                                        numbers.
                                        <br>
                                        <br>
                                        4 &nbsp;&nbsp;&nbsp;Promotion of Third Parties - We reserve the right to remove
                                        content on our social
                                        media platforms and/or forums containing promotional information of third parties,
                                        including, but not limited to: trademarks, services, offerings or brands, on our
                                        forums or
                                        social media,
                                        <br>
                                        <br>
                                        5. &nbsp;&nbsp;&nbsp;Rejection of Work/Payments - Work submitted is reviewed by our
                                        internal team. We
                                        reserve the right to reject work (with or without pay) using our discretion. Simply
                                        stated, it is
                                        not fair to us, to your fellow workers, nor to our clients to accept sub-par work
                                        that does not
                                        meet quality standards in accordance with the instructions, the style guide and/or
                                        format.
                                        <br>
                                        <br>
                                        6.&nbsp;&nbsp;&nbsp;Qualifications - We reserve the right to create, edit or revoke
                                        qualifications at any
                                        time, for any reason or for no reason.
                                        <br>
                                        <br>
                                        7.&nbsp;&nbsp;&nbsp;Monetary Awards/Career Advancement - At our discretion, workers
                                        who go above
                                        and beyond will receive both monetary awards as well as opportunities for career
                                        advancement. As you earn trust in our system, you have the potential to gain access
                                        to
                                        more assignments and/or , earnings potential.
                                        <br>
                                        <br>
                                        8.&nbsp;&nbsp;&nbsp;Monitoring Community Content - UOM-Crowd will make an honest
                                        effort to monitor
                                        content in a timely fashion, including: messages, posts, comments, photos, videos,
                                        emails)
                                        and/or other content posted by users of the community. We will make a best effort to
                                        take
                                        all constructive criticism and ideas to task, arrive at a resolution for problems
                                        and continue
                                        striving for process improvements,
                                        <br>
                                        <br>
                                        However, the best way to address support issues with UOM-Crowd is to contact our
                                        workforce support team (uomcrawd@gmail.com). Please note that we do not guarantee a
                                        [response to questions posted on third-party websites, social networks, blogs or
                                        forums,
                                        Furthermore, please remember that anything posted on our social media accounts or
                                        active
                                        forums does not necessarily represent the feelings or opinions of UOM-Crowd,
                                        <br>
                                        <br>
                                        ** Enforcement of these guidelines are solely al the discretion of UOM-Crowd, and
                                        failure
                                        to enforce such rules in some instances daes not constitute a waiver of aur rights
                                        to enforce
                                        rules in other instances,
                                        <button type="button" class="btn btn btn-lg rounded-0 mb-2"
                                                style="background-color: #972F15;color: white;margin-left: 550px">Agree
                                            <input type="radio" name="agree" value="yes"/>
                                        </button>
                                    </span>
                                </div>
                            </div>

                            <button type="submit" id="submitButton" class="btn btn btn-lg rounded-0 mb-2"
                                    onclick="checkAge(); register();"
                                    style="background-color: #972F15;color: white;margin-left: 1050px">Submit
                            </button>

                            <script>
                                // Get the input field and submit button elements
                                const inputFieldBranch = document.getElementById("Branch");
                                const inputFieldFName = document.getElementById("fname");
                                const inputFieldSName = document.getElementById("surname");
                                const inputFieldEmail = document.getElementById("email");
                                const inputFieldPassword = document.getElementById("password");
                                const inputFieldCPassword = document.getElementById("confirm_password");
                                const inputFieldMobile1 = document.getElementById("mobileOne");
                                const inputFieldMobile2 = document.getElementById("mobileTwo");
                                const inputFieldContact = document.getElementById("preferred_way_to_contact");
                                const inputFieldCStatus = document.getElementById("civil_status");
                                const inputFieldGender = document.getElementById("gender");
                                const inputFieldReligion = document.getElementById("religion");
                                const inputFieldEducation = document.getElementById("education");
                                const inputFieldEmployment = document.getElementById("employment");
                                const inputFieldLanguage = document.getElementById("language");
                                const inputFieldAddress = document.getElementById("Address");
                                const inputFieldRewards = document.getElementById("rewards");
                                const inputFieldTopUpMobile = document.getElementById("topUpMobile");
                                const inputFieldAccountName = document.getElementById("accountName");
                                const inputFieldBanks = document.getElementById("banks");
                                const inputFieldAccountNumber = document.getElementById("accNumber");
                                const inputFieldBirthday = document.getElementById("Birthday");
                                const inputFieldNIC = document.getElementById("nic");

                                const submitButton = document.getElementById("submitButton");
                                submitButton.disabled = true;

                                //
                                function enableSubmitButton() {
                                    // Check if all specified input fields have values
                                    if (
                                        inputFieldFName.value.trim() !== "" &&
                                        inputFieldBranch.value.trim() !== "" &&
                                        inputFieldAccountNumber.value.trim() !== "" &&
                                        inputFieldSName.value.trim() !== "" &&
                                        inputFieldEmail.value.trim() !== "" &&
                                        inputFieldPassword.value.trim() !== "" &&
                                        inputFieldCPassword.value.trim() !== "" &&
                                        inputFieldMobile1.value.trim() !== "" &&
                                        inputFieldMobile2.value.trim() !== "" &&
                                        inputFieldContact.value.trim() !== "" &&
                                        inputFieldCStatus.value.trim() !== "" &&
                                        inputFieldGender.value.trim() !== "" &&
                                        inputFieldReligion.value.trim() !== "" &&
                                        inputFieldEducation.value.trim() !== "" &&
                                        inputFieldEmployment.value.trim() !== "" &&
                                        inputFieldLanguage.value.trim() !== "" &&
                                        inputFieldAddress.value.trim() !== "" &&
                                        inputFieldRewards.value.trim() !== "" &&
                                        inputFieldTopUpMobile.value.trim() !== "" &&
                                        inputFieldAccountName.value.trim() !== "" &&
                                        inputFieldBanks.value.trim() !== "" &&
                                        inputFieldAccountNumber.value.trim() !== "" &&
                                        inputFieldBirthday.value.trim() !== "" &&
                                        inputFieldNIC.value.trim() !== ""
                                    ) {
                                        submitButton.disabled = false; // Enable the submit button
                                    } else {
                                        submitButton.disabled = true; // Disable the submit button
                                    }
                                }

                                // Add an event listener to each input field to check when the value changes
                                inputFieldFName.addEventListener("input", enableSubmitButton);
                                inputFieldBranch.addEventListener("input", enableSubmitButton);
                                inputFieldAccountNumber.addEventListener("input", enableSubmitButton);
                                inputFieldSName.addEventListener("input", enableSubmitButton);
                                inputFieldEmail.addEventListener("input", enableSubmitButton);
                                inputFieldPassword.addEventListener("input", enableSubmitButton);
                                inputFieldCPassword.addEventListener("input", enableSubmitButton);
                                inputFieldMobile1.addEventListener("input", enableSubmitButton);
                                inputFieldMobile2.addEventListener("input", enableSubmitButton);
                                inputFieldContact.addEventListener("input", enableSubmitButton);
                                inputFieldCStatus.addEventListener("input", enableSubmitButton);
                                inputFieldGender.addEventListener("input", enableSubmitButton);
                                inputFieldReligion.addEventListener("input", enableSubmitButton);
                                inputFieldEducation.addEventListener("input", enableSubmitButton);
                                inputFieldEmployment.addEventListener("input", enableSubmitButton);
                                inputFieldLanguage.addEventListener("input", enableSubmitButton);
                                inputFieldAddress.addEventListener("input", enableSubmitButton);
                                inputFieldRewards.addEventListener("input", enableSubmitButton);
                                inputFieldTopUpMobile.addEventListener("input", enableSubmitButton);
                                inputFieldAccountName.addEventListener("input", enableSubmitButton);
                                inputFieldBanks.addEventListener("input", enableSubmitButton);
                                inputFieldAccountNumber.addEventListener("input", enableSubmitButton);
                                inputFieldBirthday.addEventListener("input", enableSubmitButton);
                                inputFieldNIC.addEventListener("input", enableSubmitButton);

                                // Initially call the function to check if the submit button should be enabled or disabled based on the initial input field values
                                enableSubmitButton();

                                //

                                function validateNIC(nic) {

                                    const nicRegex = /^[0-9]{9}[vVxX]|[0-9]{12}$/;

                                    const nicInput = document.getElementById("nic");
                                    const submitButton = document.getElementById("submitButton"); // Replace with the actual ID of your submit button

                                    if (nicRegex.test(nic)) {
                                        nicInput.classList.remove("invalid"); // Remove any previous validation error styling
                                        submitButton.disabled = false; // Enable the submit button
                                    } else {
                                        nicInput.classList.add("invalid"); // Apply validation error styling
                                        submitButton.disabled = true; // Disable the submit button
                                    }
                                }

                                function checkPasswordMatch() {
                                    const password = document.getElementById("password");
                                    const confirm_password = document.getElementById("confirm_password");
                                    const password_match_message = document.getElementById("password_match_message");

                                    if (password.value === confirm_password.value) {
                                        confirm_password.setCustomValidity(""); // Clear any previous validation message
                                        password_match_message.style.display = "none"; // Hide the validation message
                                    } else {
                                        confirm_password.setCustomValidity("Passwords do not match");
                                        password_match_message.style.display = "block"; // Show the validation message
                                    }
                                }





                            </script>


                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    @include('layouts.footer')

    <script>

        function register() {
            const name = document.getElementById('fname').value
            const email = document.getElementById('email').value
            const confirm_password = document.getElementById('confirm_password').value
            const password = document.getElementById('password').value

            localStorage.setItem('email', email);

            // event.preventDefault();

            // var data = $("#form1").serialize();

            $.ajax({
                type: 'get',
                url: "{{ route('register') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    'name': name,
                    'email': email,
                    'password': password,
                },
            });

        }

        function checkAge() {
            var error = document.getElementById("Birthday");
            var dob = new Date("06/24/2008");
            //calculate month difference from current date in time
            var month_diff = Date.now() - dob.getTime();

            //convert the calculated difference in date format
            var age_dt = new Date(month_diff);

            //extract year from date
            var year = age_dt.getUTCFullYear();

            //now calculate the age of the user
            var age = Math.abs(year - 1970);

            if (age < 18) {
                error.textContent = "Please enter a valid number"
                error.style.color = "red"
            }
            //display the calculated age
            // document.write("Age of the date entered: " + age + " years");
        }

        function ConfirmPassCheck() {
            var pw1 = document.getElementById("password").value;
            var pw2 = document.getElementById("confirm_password").value;

            if (pw1 !== pw2) {
                alert("Passwords did not match");
            } else {
                alert("Password created successfully");
            }
        }

        function ValidateEmail(input) {

            var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

            console.log("Print -> " + input.value.match(validRegex));

            if (input.value.match(validRegex)) {
                alert("Valid email address!");
                document.getElementById("email").style.borderColor = "#ced4da";
                document.form1.text1.focus();
                return true;
            } else {
                alert("Invalid email address!");
                document.getElementById("email").style.borderColor = "red";
                document.form1.text1.focus();
                return false;
            }

        }

        function ValidateNumber(input) {
            console.log('in validate number...')
            var validation = /^([07][0|1|2|4|5|6|7|8]{1}[0-9]{8})$/;

            console.log("Print -> " + input.value.match(validation));

            if (input.value.match(validation)) {
                alert("Valid mobile number");
                document.getElementById("mobileOne").style.borderColor = "#ced4da";
                document.form1.text1.focus();
                return true;
            }else {
                alert("Invalid mobile number");
                document.getElementById("mobileOne").style.borderColor = "red";
                document.form1.text1.focus();
                return false;
            }
        }

    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
@endsection
