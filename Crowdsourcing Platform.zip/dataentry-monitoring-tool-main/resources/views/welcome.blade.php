@extends('layouts.app')

@section('content')
    <style>
        hr.spaceline {
            border: 1px solid red;
        }
         ul {
             list-style-type: none;
             margin: 0;
             padding: 0;
             overflow: hidden;
         }

        li {
            float: left;
        }

        #ll li a {
            display: block;
            color:#972F15;
            text-align: center;
            font-weight: bold;
            text-decoration: none;
            margin-left: 80px;
            text-transform: uppercase;
        }

        li a:hover {
            background-color: #FFFFFF;
        }
    </style>

    <div class="container">

        <div>
            <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto"
                 class="p-0" style="margin-left: -25px"/>
            <ul id="ll">
                <li><a href="#overview" style="margin-left: 200px">OVERVIEW</a>
                <li><a href="#features">Features</a>
                <li><a href="#rewards">REWARDS</a>
                <li><a href="#contact">CONTACT US</a>
            </ul>
        </div>
        <hr class="spaceline">


        {{--        OVERVIEW --}}
        <div class="row justify-content-center" id="overview">
            <div class="col">
                <div class="row">

                    <div class="col">
                        <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto"
                             class="p-0" style="margin-left: -25px"/>
                    </div>
                    <div class="col" style="margin-top: 25px">
                        <span class="h1 fw-semibold" style="color:#972F15;margin-left: 200px;">OVERVIEW</span>
                    </div>
                    <div class="container-fluid mt-3 row fs-5">
                        <span> UOM - CROWD is a crowdsourcing platform that makes it easier for individuals and researchers
                            to get your data labelled easily and to create high quality datasets without having to build
                            labelling applications or manage the labelling workforce on your own.</span>

                        <span class="mt-2"> We currently allow only <b>Sri Lankans</b> to register as we need our
                            workforce to be <b>Sinhala literate</b> and who possess Sri Lankan contextual ,social and
                            cultural insights .</span>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="d-flex flex-column bd-highlight mt-3">
                    <div>
                        <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="250px" height="auto"
                             style="margin-left: 155px"/>
                    </div>
                    <div class="mt-3" style="margin-left: 165px">
                        <a href="{{ route('workWithUs') }}">
                            <button type="button" class="btn btn btn-lg rounded-0"
                                    style="background-color: #972F15;color: white">Work with us
                            </button>
                        </a>
                    </div>
                    <div style="margin-left: 135px" class="mt-3">
                        <button type="button" class="btn btn-link">Learn why your help matters</button>
                    </div>
                    <div style="margin-left: 142px">
                        <a href="#rewards-section"><button type="button" class="btn btn-link">Learn more about rewards</button></a>
                    </div>
                    <div style="margin-left: 142px;margin-top: 10px;color:#972F15;font-weight:900">
                        <span>Social Media Data Analytics Team </span>
                        <span style="margin-left: 30px">University of Moratuwa</span>
                    </div>
                    <div style="margin-left: 162px;margin-top: 15px;font-weight:900">
                        <span>Research funded by <a href="https://ahead.lk/"><u>AHEAD</u></a></span>
                    </div>
                </div>
            </div>
        </div>
        {{--        DISCOVER --}}
        <div class="row justify-content-center" style="margin-top: 60px">
            <div class="col">
                <div class="row">

                    <div class="col">
                        <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto"
                             class="p-0" style="margin-left: -25px"/>
                    </div>
                    <div class="col" style="margin-top: 25px">
                        <span class="h1 fw-semibold" style="color:#972F15;margin-left: 0px;">DISCOVER LABELLING TASK
                            TYPES</span>
                    </div>

                    {{-- CARD --}}
                    <div>
                        <div class="card-group mt-5">
                            <div class="card">
                                <img class="card-img-top" src="{{ asset('images/im1.jpg') }}" alt="Card image cap"
                                     style="height:180px;object-fit: cover;">
                                <div class="card-body">
                                    <h5 class="card-title fw-bolder" style="text-align: center">Inappropriate Content
                                        Identification</h5>
                                    </p>
                                </div>
                            </div>
                            <div class="card">
                                <img class="card-img-top" src="{{ asset('images/im2.png') }}" alt="Card image cap"
                                     style="height:180px;object-fit: cover;">
                                <div class="card-body">
                                    <h5 class="card-title fw-bolder" style="text-align: center">Image Text
                                        Identification</h5>
                                </div>
                            </div>
                            <div class="card">
                                <img class="card-img-top" src="{{ asset('images/im3.jpg') }}" alt="Card image cap"
                                     style="height:180px;object-fit: cover;">
                                <div class="card-body">
                                    <h5 class="card-title fw-bolder" style="text-align: center">Hate Speech
                                        Identification</h5>
                                </div>
                            </div>
                            <div class="card">
                                <img class="card-img-top" src="{{ asset('images/im4.png') }}" alt="Card image cap"
                                     style="height:180px;object-fit: cover;">
                                <div class="card-body">
                                    <h5 class="card-title fw-bolder" style="text-align: center">Hate Speech Content
                                        Propagator Identification</h5>
                                </div>
                            </div>
                            <div class="card">
                                <img class="card-img-top" src="{{ asset('images/im5.png') }}" alt="Card image cap"
                                     style="height:180px;object-fit: cover;">
                                <div class="card-body">
                                    <h5 class="card-title fw-bolder" style="text-align: center">Sentiment Analysis</h5>
                                </div>
                            </div>
                            <div class="card">
                                <img class="card-img-top" src="{{ asset('images/im6.png') }}" alt="Card image cap"
                                     style="height:180px;object-fit: cover;">
                                <div class="card-body">
                                    <h5 class="card-title fw-bolder" style="text-align: center">Hate Corpus
                                        Generation</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        {{--        HOW DOES IT WORK --}}
        <div class="row justify-content-center" style="margin-top: 60px">
            <div class="card" style="border: 2px solid black;">
                <div class="row">
                    <div class="col">
                        <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto"
                             class="p-0" style="margin-left: -25px"/>
                    </div>
                    <div class="col" style="margin-top: 25px">
                        <span class="h1 fw-semibold" style="color:#972F15;margin-left: 240px;">HOW DOES IT WORK ?</span>
                    </div>
                </div>
                <div class="row">
                    {{--                    <div class="mt-0" style="width:1300px;height: 400px;background-color: #4a5568"></div> --}}
                    <img src="{{ asset('images/how_to_work.png') }}" width="220px" height="auto" class="p-0"
                         style="margin-left: -25px"/>
                    <div class="d-flex flex-column bd-highlight mt-3">
                        <span class="fs-5" style="font-weight:bolder">1. &nbsp;&nbsp;&nbsp;&nbsp; Register Contribution
                        </span>
                        <span class="fs-5 mt-2 p-3" style="font-weight: 600;">Anyone interested in serving the cause of
                            creating better cyberspace can register as a worker through
                            the system by signing up using the "Work with Us" button.
                        </span>
                        <span class="fs-5 mt-2" style="font-weight:bolder">2. &nbsp;&nbsp;&nbsp;&nbsp; Select Contribution
                        </span>
                        <span class="fs-5 mt-2 p-3" style="font-weight: 600;">Those who are literate in Sinhala and Sri
                            Lankan natives will be selected as contributors . Those who do
                            not qualify in the pre - selection process , fail at quality control , and fail at the
                            trustworthiness ensuring
                            process will be eliminated by being a contributor to the platform .
                        </span>

                        <div class="d-flex flex-column bd-highlight">
                            <span class="fs-5 mt-3" style="font-weight:bold">Pre-Selection Contributors</span>

                            <span class="p-0 mt-3" style="font-weight:bolder">The pre - selection process would involve
                                checking the qualified criterion given below;</span>
                            <li class="p-1" style="font-weight:bolder">Should be a Sri Lankan</li>
                            <li class="p-1" style="font-weight:bolder">Age more than 18 years</li>
                            <li class="p-1" style="font-weight:bolder">Should meet the given criteria in the tests to
                                assess ; prior knowledge in hate speech
                                identification ,
                                Sinhala language proficiency , ability to read Sinhala words written in English letters
                                , comprehension , and
                                analytical skills.
                            </li>

                            <li class="p-1 mt-3" style=" list-style-type: circle;font-weight:bolder">Knowledge of hate
                                speech
                                > = 5 out of 10
                            </li>
                            <li class="p-1" style=" list-style-type: circle;font-weight:bolder">Sinhala language
                                proficiency > = 8 out of 10
                            </li>
                            <li class="p-1" style=" list-style-type: circle;font-weight:bolder">Sinhala comprehension
                                and analytical skills > = 8 out of 10
                            </li>
                            <li class="p-1" style=" list-style-type: circle;font-weight:bolder">Ability to read Sinhala
                                words written in English letters > = 8 out of 10
                            </li>

                            <span class="fs-5 mt-3" style="font-weight:bolder">3. &nbsp;&nbsp;&nbsp;&nbsp; Assess response
                                quality </span>
                            <div class="mt-0">
                                <button type="button" class="btn btn-link">Learn how we calculate the response quality
                                </button>
                            </div>

                            <span class="fs-5 mt-3" style="font-weight:bolder">Take Selection</span>
                            <span style="font-weight:bolder" class="p-1">You will be asked questions randomly based on
                                a question generation mechanism helping to generate a
                                corpus with hate speech, annotate the posts to detect and classify the intention of the hate
                                speech,
                                identify Sinhala texts from images, to identify inappropriate words in the social media
                                content and to sort
                                Sinhala, Singlish and English words in a given set of social media posts.
                            </span>

                            <span class="fs-5 mt-3" style="font-weight:bolder">Fire Questions</span>
                            <span style="font-weight:bolder" class="p-1">Fire questions to selected contributors based
                                on pre-selected contributors using a question firing
                                mechanism such as a decision tree. Some categories of such questions would be to check the
                                credibility
                                of information shared on social media, to check fake profiles, and to capture user opinions
                                and
                                behaviour. Generate advanced questions as given below after aggregating the responses from
                                the
                                contributors.
                            </span>
                            <span style="font-weight:bolder">E.g. This is flagged content as hate speech. But x number of
                                people have shared it. Why do you think
                                people keep sharing it?
                            </span>

                            <li class="ms-lg-4" style="font-weight:bolder">Because it is fun</li>
                            <li class="ms-lg-4" style="font-weight:bolder">Sarcasm</li>
                            <li class="ms-lg-4" style="font-weight:bolder">lrony</li>

                            <span class="fs-5 mt-3" style="font-weight:bolder">Assign Rewards( Extrinsic
                                Motivators)</span>

                            <span style="font-weight:bolder" class="p-1">
                                Workers will be able to achieve monetary awards as stated in “Rewards” considering the
                                completion
                                levels, accuracy, the trustworthiness of the contributor, etc.
                            </span>

                            <span class="fs-5 mt-3" style="font-weight:bolder">Assign Rewards( Intrinsic
                                Motivators)</span>

                            <span style="font-weight:bolder" class="p-1">In the end, you are contributing to making
                                cyberspace better. Therefore to admire your effort apart from
                                the monetary rewards the contributors who earn a higher trustworthiness score and based on
                                the human
                                intelligence tasks(HITs) completed badges will be given. The platform would provide a gaming
                                experience for contributors to retain in the cause. Intrinsic and extrinsic motivators will
                                be embedded in
                                the gaming experience.
                            </span>

                            <span class="fs-5 mt-3" style="font-weight:bolder">Model the trustworthiness of a
                                contributor</span>

                            <span style="font-weight:bolder" class="p-1">
                                An inbuilt mechanism is being used to check the trustworthiness of the responses of a
                                particular
                                contributor and to assign a badge for trustworthiness. A higher weightage of validity to the
                                response from
                                a trustworthiness badge-owned contributor will be considered in assessing the quality of the
                                response.
                            </span>
                            <span class="fs-5 mt-3" style="font-weight:bolder">Aggregation of contributions</span>

                            <span style="font-weight:bolder" class="p-1">
                                Evaluates the results based on human judgment for each post store the results, ignored, hate
                                speech or not, category of the hate nature, etc to aggregate the contributions and to
                                generate
                                advanced questions
                                at a later stage.
                            </span>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        {{--        Features --}}
        <div class="row justify-content-center" style="margin-top: 60px" id="features">
            <div class="row">
                <div class="col">
                    <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto"
                         class="p-0" style="margin-left: -25px"/>
                </div>
                <div class="col" style="margin-top: 35px">
                    <span class="h1 fw-semibold" style="color:#972F15;margin-left: 400px;">FEATURES</span>
                </div>
            </div>
            <div class="row">
                <span class="h1 fw-semibold" style="color:#972F15;margin-left:0px;margin-top: 60px">You could help solve
                    the greatest challenges in labelling data</span>

                <div class="card" style="border: 2px solid black;">
                    <span class="fs-5 mt-3" style="font-weight:bolder">You will help us with labelling</span>
                    <li class="p-1" style="font-weight:bolder">Inappropriate contents</li>
                    <li class="p-1" style="font-weight:bolder">Text from images</li>
                    <li class="p-1" style="font-weight:bolder">Hate speech written in Sinhala, Sinhala words written
                        in
                        English letters(Singlish), English.
                    </li>
                    <li class="p-1" style="font-weight:bolder">Hate content propagators</li>
                    <li class="p-1" style="font-weight:bolder">Sentiments</li>
                    <li class="p-1" style="font-weight:bolder">Fake News</li>
                    <li class="p-1" style="font-weight:bolder">Corpus generation related to hate</li>
                    <li class="p-1" style="font-weight:bolder">Differentiate Sinhala, Singlish and English words in
                        social media posts.
                    </li>
                </div>

            </div>

        </div>
        {{--        REWARDS --}}


        <div class="row justify-content-center" style="margin-top: 60px" id="rewards">
            <div class="row">
                <div class="col">
                    <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto"
                         class="p-0" style="margin-left: -25px"/>
                </div>
                <div class="col" style="margin-top: 35px">
                    <span id="rewards-section" class="h1 fw-semibold" style="color:#972F15;margin-left: 400px;">REWARDS</span>                </div>
            </div>
            <div class="row mt-2">
                <span style="font-weight: normal" class="p-1">Crowdsource rewards are subject to contributions passing
                    a quality control review. You will be able to
                    achieve monetary rewards based on the badges you will be obtaining. A badge is a validated indicator of
                    accomplishment, skill, and quality of your work. Badges will be given after you achieve certain
                    milestones.</span>
                <span style="font-weight:normal" class="p-1">
                    Soon after your registration process, you will be given a badge as a <b>CONTRIBUTOR.</b>
                </span>
                <span style="font-weight:normal" class="p-1">
                    Next when your complete LEVEL 0, with a satisfactory quality control review pass, you will be givena
                    badge as a <b>SELECTED CONTRIBUTOR</b>. Only the selected contributors can achieve monetary rewards.
                </span>

                <span style="font-weight:normal" class="p-1">
                    You will be able to gain points thereafter to achieve the remaining points. You can obtain one point by
                    completing ONE Human Intelligent Task (HIT) and agreement received. A HIT is a question that needs
                    an answer. Points help you level up and claim virtual badges and thereby virtual rewards.
                </span>

                <span style="font-weight: bold;font-size: 25px;margin-left: -10px" class="mt-3">LEVEL 0</span>

                <span class="mt-3">At LEVEL 0 you will be assessed for the following as a qualified review.</span>

                <li class="p-2 mt-2" style="font-weight:bolder">prior knowledge in hate speech identification</li>
                <li class="p-2" style="font-weight:bolder">Sinhala language proficiency</li>
                <li class="p-2" style="font-weight:bolder">Ability to read Sinhala words written in English letters
                </li>
                <li class="p-2" style="font-weight:bolder">Comprehension and analytical skills.</li>

                <span class="mt-3">Furthermore, few questions will be asked to obtain context-specific details such as
                    your;</span>

                <li class="p-2 mt-2" style="font-weight:bolder">Personality</li>
                <li class="p-2" style="font-weight:bolder">User opinion on social media content</li>
                <li class="p-2" style="font-weight:bolder">Beliefs</li>
                <li class="p-2" style="font-weight:bolder">Knowledge of social media platform standards</li>
                <li class="p-2" style="font-weight:bolder">Biases</li>
            </div>
        </div>
        {{--        ALL LEVELS AND BADGES --}}
        <div class="row justify-content-center" style="margin-top: 60px">
            <div class="row">
                <div class="col">
                    <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto"
                         class="p-0" style="margin-left: -25px"/>
                </div>
                <div class="col" style="margin-top: 35px">
                    <span class="h1 fw-semibold" style="color:#972F15;margin-left: 170px;">ALL LEVELS AND BADGES</span>
                </div>
            </div>
            <div class="row">
                <div class="col mt-5">
                    <img src="{{ asset('images/lock.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 165px"/>
                    <span class="fs-4" style="font-weight: bold;margin-left: -25px">REGISTRATION</span>
                    <img src="{{ asset('images/gift.png') }}" width="20px" height="auto" class="p-0"
                         style="margin-left:-100px;margin-top: 39px"/>
                    <button type="button" class="btn btn-link" style="margin-top: 39px;margin-left: -10px">Unlock your
                        CONTRIBUTOR badge
                    </button>
                </div>
                <div class="col" style="margin-top: 70px">
                    <span class="fs-4" style="font-weight: bold;margin-left:175px">0 Points</span>
                    <img src="{{ asset('images/Contributor.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 55px"/>
                </div>
            </div>
            <div class="row">
                <div class="col mt-5">
                    <img src="{{ asset('images/lock.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 155px"/>
                    <span class="fs-4" style="font-weight: bold;margin-left: -25px">LEVEL 0</span>
                    <img src="{{ asset('images/gift.png') }}" width="20px" height="auto" class="p-0"
                         style="margin-left:-25px;margin-top: 39px"/>
                    <button type="button" class="btn btn-link" style="margin-top: 39px;margin-left: -10px">Unlock your
                        CONTRIBUTOR badge
                    </button>
                </div>
                <div class="col" style="margin-top: 70px">
                    <span class="fs-4" style="font-weight: bold;margin-left:175px">0 Points</span>
                    <img src="{{ asset('images/Contributor.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 55px"/>
                </div>
            </div>
            <div class="row">
                <div class="col mt-5">
                    <img src="{{ asset('images/lock.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 155px"/>
                    <span class="fs-4" style="font-weight: bold;margin-left: -25px">LEVEL 1</span>
                </div>
                <div class="col" style="margin-top: 70px">
                    <span class="fs-4" style="font-weight: bold;margin-left:175px">50 Points</span>
                    <img src="{{ asset('images/Contributor.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 45px"/>
                </div>
            </div>
            <div class="row">
                <div class="col mt-5">
                    <img src="{{ asset('images/lock.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 155px"/>
                    <span class="fs-4" style="font-weight: bold;margin-left: -25px">LEVEL 2</span>
                </div>
                <div class="col" style="margin-top: 70px">
                    <span class="fs-4" style="font-weight: bold;margin-left:175px">75 Points</span>
                    <img src="{{ asset('images/Contributor.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 45px"/>
                </div>
            </div>
            <div class="row">
                <div class="col mt-5">
                    <img src="{{ asset('images/lock.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 155px"/>
                    <span class="fs-4" style="font-weight: bold;margin-left: -25px">LEVEL 3</span>
                    <img src="{{ asset('images/gift.png') }}" width="20px" height="auto" class="p-0"
                         style="margin-left:-25px;margin-top: 39px"/>
                    <button type="button" class="btn btn-link" style="margin-top: 39px;margin-left: -10px">Unlock your
                        CONTRIBUTOR badge
                    </button>
                </div>
                <div class="col" style="margin-top: 70px">
                    <span class="fs-4" style="font-weight: bold;margin-left:175px">100 Points</span>
                    <img src="{{ asset('images/Contributor.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 30px"/>
                </div>
            </div>
            <div class="row">
                <div class="col mt-5">
                    <img src="{{ asset('images/lock.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 155px"/>
                    <span class="fs-4" style="font-weight: bold;margin-left: -25px">LEVEL 4</span>
                    <img src="{{ asset('images/gift.png') }}" width="20px" height="auto" class="p-0"
                         style="margin-left:-25px;margin-top: 39px"/>
                    <button type="button" class="btn btn-link" style="margin-top: 39px;margin-left: -10px">Unlock your
                        CONTRIBUTOR badge
                    </button>
                </div>
                <div class="col" style="margin-top: 70px">
                    <span class="fs-4" style="font-weight: bold;margin-left:175px">200 Points</span>
                    <img src="{{ asset('images/Contributor.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 30px"/>
                </div>
            </div>
            <div class="row">
                <div class="col mt-5">
                    <img src="{{ asset('images/lock.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 155px"/>
                    <span class="fs-4" style="font-weight: bold;margin-left: -25px">LEVEL 5</span>
                </div>
                <div class="col" style="margin-top: 70px">
                    <span class="fs-4" style="font-weight: bold;margin-left:175px">350 Points</span>
                    <img src="{{ asset('images/Contributor.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 30px"/>
                </div>
            </div>
            <div class="row">
                <div class="col mt-5">
                    <img src="{{ asset('images/lock.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 155px"/>
                    <span class="fs-4" style="font-weight: bold;margin-left: -25px">LEVEL 6</span>
                    <img src="{{ asset('images/gift.png') }}" width="20px" height="auto" class="p-0"
                         style="margin-left:-25px;margin-top: 39px"/>
                    <button type="button" class="btn btn-link" style="margin-top: 39px;margin-left: -10px">Unlock your
                        CONTRIBUTOR badge
                    </button>
                </div>
                <div class="col" style="margin-top: 70px">
                    <span class="fs-4" style="font-weight: bold;margin-left:175px">500 Points</span>
                    <img src="{{ asset('images/Contributor.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 30px"/>
                </div>
            </div>
            <div class="row">
                <div class="col mt-5">
                    <img src="{{ asset('images/lock.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 155px"/>
                    <span class="fs-4" style="font-weight: bold;margin-left: -25px">LEVEL 7</span>
                </div>
                <div class="col" style="margin-top: 70px">
                    <span class="fs-4" style="font-weight: bold;margin-left:175px">750 Points</span>
                    <img src="{{ asset('images/Contributor.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 30px"/>
                </div>
            </div>
            <div class="row">
                <div class="col mt-5">
                    <img src="{{ asset('images/lock.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 155px"/>
                    <span class="fs-4" style="font-weight: bold;margin-left: -25px">LEVEL 8</span>
                    <img src="{{ asset('images/gift.png') }}" width="20px" height="auto" class="p-0"
                         style="margin-left:-25px;margin-top: 39px"/>
                    <button type="button" class="btn btn-link" style="margin-top: 39px;margin-left: -10px">Unlock your
                        CONTRIBUTOR badge
                    </button>
                </div>
                <div class="col" style="margin-top: 70px">
                    <span class="fs-4" style="font-weight: bold;margin-left:175px">1000 Points</span>
                    <img src="{{ asset('images/Contributor.png') }}" width="100px" height="auto" class="p-0"
                         style="margin-left: 20px"/>
                </div>
            </div>
        </div>
        {{--        CONTACT --}}

        <div class="row justify-content-center" style="margin-top: 60px" id="contact">
            <div class="row">
                <div class="col">
                    <img src="{{ asset('images/CrowdsourcingPlatformLogo.png') }}" width="220px" height="auto"
                         class="p-0" style="margin-left: -25px"/>
                </div>
                <div class="col" style="margin-top: 35px">
                    <span class="h1 fw-semibold" style="color:#972F15;margin-left: 420px;">CONTACT</span>
                </div>
            </div>
            <div class="row">
                <span style="font-weight: bold" class="mt-5 fs-4">For all inquiries please contact</span>
                <span style="font-weight: bold" class=" fs-4 mt-2">G. S. Nadeera Meedin</span>
                <span style="font-weight: bold" class="mt-3 fs-4">Email :</span>
                <span style="font-weight: bold;margin-left: 45px" class="fs-4">uomcrowd@gmail.com</span>
                <span style="font-weight: bold" class="mt-3 fs-4">Contact No :</span>
                <span style="font-weight: bold;margin-left: 45px" class="fs-4">+94773772081</span>
            </div>
        </div>
    </div>

    @include('layouts.footer')
@endsection

<script>
    var prevScrollpos = window.pageYOffset;
    window.onscroll = function () {
        var currentScrollPos = window.pageYOffset;
        if (prevScrollpos > currentScrollPos) {
            document.getElementById("navbar").style.top = "0";
        } else {
            document.getElementById("navbar").style.top = "-50px";
        }
        prevScrollpos = currentScrollPos;
    }
</script>




