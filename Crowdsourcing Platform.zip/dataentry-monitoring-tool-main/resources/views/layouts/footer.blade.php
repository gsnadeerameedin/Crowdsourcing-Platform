<footer>
    <p style="margin-left: 25px"> © Social Media Analytic Research Group, University of Moratuwa. </p>
</footer>
