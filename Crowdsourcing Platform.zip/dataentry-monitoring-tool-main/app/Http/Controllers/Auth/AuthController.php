<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{

    public function register(Request $request)
    {
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password)
        ]);

//        $token = $user->createToken('token')->plainTextToken;

        $response = [
            'user' => $user,
//            'token' => $token
        ];

        return response($response, 201);
    }

    public function checkLogin(Request $request)
    {
        $fields = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:4|max:12'
        ]);

        $user = User::where('email', $fields['email'])->first();

        if (!$user || !Hash::check($fields['password'], $user->password)) {
            return response(['message' => 'Bad credits'], 401);
        }

//        $response = [
//            'user' => $user,
//        ];

//        return response($response, 201);
        return view('labelling_task_type');
    }

    public function login(Request $request)
    {

        return view('auth.login');

    }

    public function logout(): JsonResponse
    {
        error_log("in logout");
        auth()->user()->tokens()->delete();

        return response()->json('Logged out');

    }
}
