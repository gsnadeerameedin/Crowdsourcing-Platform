<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('profiles', function (Blueprint $table) {
            $table->id();
            $table->string('firstname')->nullable();
            $table->string('surname')->nullable();
            $table->string('email')->nullable();
            $table->double('mobile_two')->nullable();
            $table->double('mobile_one')->nullable();
            $table->string('civil_status')->nullable();
            $table->string('religion')->nullable();
            $table->string('birthday')->nullable();
            $table->string('nic')->nullable();
            $table->string('nature_of_emp')->nullable();
            $table->string('language')->nullable();
            $table->string('address')->nullable();
            $table->string('monetary_rewards')->nullable();
            $table->string('top_up_mobile')->nullable();
            $table->string('account_name')->nullable();
            $table->string('bank')->nullable();
            $table->string('branch')->nullable();
            $table->string('acc_number')->nullable();
            $table->string('preferred_contact')->nullable();
            $table->string('gender')->nullable();
            $table->string('education')->nullable();
            $table->string('updated_at')->nullable();
            $table->string('created_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('profiles');
    }
};
