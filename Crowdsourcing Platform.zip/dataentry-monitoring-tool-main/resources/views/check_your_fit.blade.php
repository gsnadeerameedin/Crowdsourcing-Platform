@extends('layouts.app')
@section('content')
    <script>
        function show(shown, hidden, third, fourth, fifth) {
            document.getElementById(shown).style.display = 'block';
            document.getElementById(hidden).style.display = 'none';
            document.getElementById(third).style.display = 'none';
            document.getElementById(fourth).style.display = 'none';
            document.getElementById(fifth).style.display = 'none';
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
            return false;
        }


    </script>
    <div class="container">
        <div class="col">
            <div class="row">
                <div class="col" style="margin-left: 300px">
                    <span class="h1 fw-semibold" style="color:#972F15;margin-left: 200px;">Check Your Fit</span>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="row" style="margin-top: -40px; margin-left: -40px">
                <div class="col">
                    <img src="{{ asset('images/STEP 1Y.png') }}" width="320px" height="auto" class="p-0"
                         style="margin-left: 160px"/>
                    <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                         style="margin-left: -130px"/>


                    <img src="{{ asset('images/STEP 2Y.png') }}" width="320px" height="auto" class="p-0"
                         style="margin-left: -130px"/>
                    <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                         style="margin-left: -130px"/>


                    <img src="{{ asset('images/STEP 3.png') }}" width="320px" height="auto" class="p-0"
                         style="margin-left: -130px"/>
                    <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                         style="margin-left: -130px"/>


                    <img src="{{ asset('images/STEP 4Y.png') }}" width="320px" height="auto" class="p-0"
                         style="margin-left: -130px"/>
                </div>
            </div>
            <div class="row">

                <div class="col fw-bold" style="margin-top: -100px;margin-left: 280px">
                    <span>Get Started</span>
                    <span style="margin-left: 120px">Create Your Profile</span>
                    <span style="margin-left: 110px">Check Your Fit</span>
                    <span style="margin-left: 110px">Start the Journey</span>
                </div>
            </div>


            {{--            PAGE 1 --}}

            <div id="Page1">
                <div class="row fw-bold fs-4" style="margin-top: 0px;text-align: center">
                    <span>Congratulations! Now you are a “CONTRIBUTOR’ . You can start your journey</span>
                </div>

                <img src="{{ asset('images/Contributor.png') }}" width="500px" height="auto" class="p-0 mt-5"
                     style="align-items: center;margin-left: 400px"/>


                <div class="col">
                    <div class="mt-3" style="margin-left: 165px">
                        <a href="" onclick="return show('Page2','Page1','Page5','Page3','Page4');">
                            <button type="button" class="btn btn btn-lg rounded-0 mt-4"
                                    style="background-color: #972F15;color: white;margin-left: 800px">Next&nbsp;&nbsp;>>
                            </button>
                        </a>
                    </div>
                </div>
            </div>

            {{--            PAGE 2 --}}


            <div id="Page2" style="display:none">
                <div class="row" style="margin-top: -40px">
                    <div class="row mt-5">
                        <div class="col">
                            <div class="col" style="margin-left: 20px;margin-top: -50px">
                                <span class=" fw-semibold" style="color:#972F15;font-size: 17px">This section has four
                                    sections with 10
                                    questions in each section to assess Sinhala language
                                    proficiency, ability to read Sinhala words written in English letters, prior knowledge
                                    in hate
                                    speech
                                    identification, comprehension, and analytical skills.</span>
                            </div>

                        </div>
                    </div>
                    <div class="col">
                        <img src="{{ asset('images/section 1G.png') }}" width="300px" height="auto" class="p-0"
                             />
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 2B.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -100px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 3B.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -100px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 4B.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -117px"/>
                    </div>
                </div>
                <div class="row" style="margin-top: -100px; width: 1268px; margin-left: -102px">

                    <div class="col fw-bold" style="margin-left: 160px">
                        <span>Sinhala Language Proficiency</span>
                    </div>
                    <div class="col fw-bold" style="margin-left: -570px;text-align: center">
                        <span>Ability to read Sinhala words <br> written in English</span>

                    </div>
                    <div class="col fw-bold" style="margin-left: -380px;text-align: center">
                        <span>Prior Knowledge in Hate <br> Speech Identification</span>
                    </div>
                    <div class="col fw-bold" style="margin-left: -440px;text-align: center">
                        <span style="margin-left: 200px">Sinhala Comprehension and Analytical Skills</span>
                    </div>

                </div>
                <div class="col">
                    <div class="col" style="margin-left: 20px;margin-top: 40px;text-align: center">
                        <span class=" fw-semibold" style="color:#c00219;font-size: 17px">Please answer all questions check
                            your fit to start the journey in UOM-CROWD</span>
                    </div>

                </div>

                <div id="quiz"></div>
                <div id="results"></div>

                <div class="col">
                    <div class="mt-3" style="margin-left: 165px">
                        <a href="" onclick="return show('Page3','Page1','Page2','Page4','Page5');">
                            <button type="button" class="btn btn btn-lg rounded-0 mt-4" id="submit"
                                    style="background-color: #972F15;color: white;margin-left: 800px">Next&nbsp;&nbsp;>>
                            </button>
                        </a>
                        <a href="" onclick="return show('Page1','Page4','Page3','Page2','Page5');">
                            <button type="button" class="btn btn btn-lg rounded-0 mt-4"
                                    style="background-color: #972F15;color: white;margin-left: -1000px">
                                <<&nbsp;&nbsp;Back
                            </button>
                        </a>
                    </div>
                </div>
            </div>
            <script>
                let allCorrectAns1 = [];
                var correctAnswers2;
                var allanswers1 = 0;
                var myQuestions = [
                    {
                        question: "(1) ඔවුන් දෙදෙනා වැඩ කෙළේ <b> දිවෙන් දිව ගාගෙනය.</b> වාක්‍යයෙහි තද කලු අකුරින් මුද්‍රිත කොටසේ අර්ථයට වඩාත් සමීප අර්ථයට දෙන උත්තරය තෝරන්න.",
                        answers: {
                            a: "ඥාතීන් මෙන්ය",
                            b: "හැම විටම එක තැන සිටය",
                            c: "ඉතා මිත්‍රශීලීව",
                            d: "දිව එකිනෙක ස්පර්ශ කරමින්ය",
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(2) පාලකයන් සමඟ කටයුතු කළ යුත්තේ <b>දැලිපිහියෙන් කිරි කන්නා සේය.</b> වාක්‍යයෙහි තද කලු අකුරින් මුද්‍රිත කොටසේ අර්ථයට වඩාත් සමීප අර්ථයට දෙන උත්තරය තෝරන්න.",
                        answers: {
                            a: "ඉතා පරිස්සමින්",
                            b: "කැපෙනවට බියෙනි",
                            c: "දුරින් සිටිමිනි",
                            d: "ඇගලුම්කම් පාමිනි",
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(3) අක්කාගේ විවාහය ප්‍රමාද වූයේ අම්මාගේ <b>වංසේ කබල්‌ ගෑ නිසාය.</b> වාක්‍යයෙහි තද කලු අකුරින් මුද්‍රිත කොටසේ අර්තයට වඩාත් සමීප අර්තය දෙන උත්තරය තෝරන්න.",
                        answers: {
                            a: "තම පරම්පරාව ගැන කියූ නිසා",
                            b: "තමා ගැන පුරසාරම්‌ කියූ නිසා",
                            c: "මනාල පාර්ශවයේ අඩුපාඩු කියූ නිසා",
                            d: "තම පරම්පරාව ගැන පුරසාරම්‌ කියූ නිසා",
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(4) වර්තමාන ශිෂ්‍ය පරම්පරාව වෙතින් කෙමෙන්‌ කෙමෙන්‌ ආත්ම................. ඉවත් වනු පෙනෙයි.හිස්නැනට වඩාන්‌ සුදුසු පදය තෝරන්න.",
                        answers: {
                            a: "අධීක්ෂණය",
                            b: "ශික්ෂණය",
                            c: "සමීක්ෂණය",
                            d: "හිංසනය",
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(5) විවාද කණ්ඩායමේ නායකයා තම කරුණු................. ඔප්පු කළේය.හිස්නැනට වඩාන්‌ සුදුසු පදය තෝරන්න.",
                        answers: {
                            a: "තර්කානුකූලව",
                            b: "නීත්‍යානුකූලව",
                            c: "ධර්මානුකූල",
                            d: "ආගමානුකූලව",
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(6) අන්ධ විශ්වාසවල එල්බ සිටින්නෝ තම................. පවා දෙති..හිස්නැනට වඩාන්‌ සුදුසු පදය නෝරන්න.",
                        answers: {
                            a: "ආත්මය",
                            b: "දෛවය",
                            c: "බුද්ධිය",
                            d: "ධනය",
                        },
                        correctAnswer: "a",
                    }, {
                        question: " (7) <b> ප්‍රථිඋපකාර</b> කරන්නෝ අප සමාජයේ විරල ය. වාක්‍යයෙහි තද කළු අකුරෙන්‌ මුද්‍රිත කොටසේ අර්ථය නිවැරදිව දැක්වෙන වරණය තෝරන්න",
                        answers: {
                            a: "බෙහෙවින්‌ උපකාර",
                            b: "පරෝපකාර",
                            c: "නැවන උපකාර",
                            d: "නොකඩවා උපකාර",
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(8) සමහරු වැඩිහිටියන්‌ කෙරෙහි <b>සානුකම්පිත වෙති.</b> වාක්‍යයෙහි තද කළු අකුරෙන්‌ මුද්‍රිත කොටසේ අර්ථය නිවැරදිව දැක්වෙන වරණය තෝරන්න",
                        answers: {
                            a: "අනුකම්පා සහගත",
                            b: "අනුකම්පා විරහිත",
                            c: "අනුකම්පා හරිත",
                            d: "අනුකම්පා පූර්වක",
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(9) අපි රට ගොඩනැඟීමට <b>එකාබද්ධව</b> කටයුතු කරමු. වාක්‍යයෙහි තද කළු අකුරෙන්‌ මුද්‍රිත කොටසේ අර්ථය නිවැරදිව දැක්වෙන වරණය තෝරන්න",
                        answers: {
                            a: "එකා මෙන් එකට බැඳී",
                            b: "එකට ඇලී",
                            c: "එකට බැඳී",
                            d: "එකාවන් ව නැගී සිට",
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(10) දී ඇති අදහසට වඩාත් ම ගැළපෙන ප්‍රස්තා පිරුළ අන්තර්ගත වරණය තෝරන්න. <br> නිෂ්ඵල ක්‍රියාවක නිරත වීම",
                        answers: {
                            a: "අබරා සිල්‌ ගන්නා වාගේ",
                            b: "පරංගියා කෝට්ටේ ගියා වගේ",
                            c: "අටුවා කඩා පුටුව හදන්න වාගේ",
                            d: "අන්දරේ සීනි කෑවා වාගේ",
                        },
                        correctAnswer: "a",
                    },

                ];

                var quizContainer = document.getElementById("quiz");
                var resultsContainer = document.getElementById("results");
                var submitButton = document.getElementById("submit");

                generateQuiz(myQuestions, quizContainer, resultsContainer, submitButton);

                function generateQuiz(
                    questions,
                    quizContainer,
                    resultsContainer,
                    submitButton
                ) {
                    function showQuestions(questions, quizContainer) {
                        // we'll need a place to store the output and the answer choices
                        var output = [];
                        var answers;

                        // for each question...
                        for (var i = 0; i < questions.length; i++) {
                            // first reset the list of answers
                            answers = [];

                            // for each available answer...
                            for (letter in questions[i].answers) {
                                // ...add an html radio button
                                answers.push(
                                    "<label>" + '<input type="radio" name="question' + i + '" value="' + letter + '">' + letter + ": " + questions[i].answers[letter] + "</label>"
                                );
                            }

                            // add this question and its answers to the output
                            output.push(
                                '<div class="row mt-4">' +
                                '   <div class="col fs-4">' +
                                '<span class="question">' +
                                questions[i].question +
                                '</span>' +
                                "</div>" +
                                '<div class="row fs-5 p-4 answers">' +
                                answers.join("") +
                                "</div>"
                            );
                        }

                        // finally combine our output list into one string of html and put it on the page
                        quizContainer.innerHTML = output.join("");
                    }

                    function showResults(questions, quizContainer, resultsContainer) {
                        // gather answer containers from our quiz
                        var answerContainers = quizContainer.querySelectorAll(".answers");

                        // keep track of user's answers
                        var userAnswer = "";
                        var numCorrect = 0;

                        // alert(quizContainer.length);

                        localStorage.setItem("allCorrectAns1", JSON.stringify(allCorrectAns1));
                        console.log("added to local allCorrectAns1")
                        // for each question...
                        for (var i = 0; i < questions.length; i++) {
                            // find selected answer
                            userAnswer = (
                                answerContainers[i].querySelector(
                                    "input[name=question" + i + "]:checked"
                                ) || {}
                            ).value;
                            console.log(userAnswer);

                            allCorrectAns1.push(userAnswer);
                            console.log('pushed data to allCorrectAns1')
                            // if answer is correct
                            if (userAnswer == "a" || userAnswer == "b" || userAnswer == "c" || userAnswer == "d" || userAnswer == "e" || userAnswer == "f") {
                                allanswers1++;
                                if (userAnswer === questions[i].correctAnswer) {
                                    // add to the number of correct answers
                                    numCorrect++;

                                    // color the answers green
                                    // answerContainers[i].style.color = "lightgreen";
                                }
                                // if answer is wrong or blank
                                else {

                                }
                            }
                        }

                        console.log("All ANswers are1  :", allanswers1);

                        // show number of correct answers out of total
                        correctAnswers2 = numCorrect;
                        // resultsContainer.innerHTML =
                        //     numCorrect + " out of " + questions.length;

                        // function loadDataFromFirstPage() {
                        //     console.log('loadDataFromFirstPage method')
                        //     var savedAnswers = JSON.parse(localStorage.getItem("allCorrectAns1"));
                        //     console.log("allCorrectAns1 "+savedAnswers);
                        //
                        //     // Loop through each saved answer and set the corresponding radio button
                        //     for (let i = 0; i < savedAnswers.length; i++) {
                        //
                        //         // Get the radio button with the matching value
                        //         let radioButton = document.querySelector('input[type="radio"][name="question'+i+'"][value="'+savedAnswers[i]+'"]');
                        //
                        //         // If the radio button exists, set it as checked
                        //         if (radioButton) {
                        //             console.log("in if...")
                        //             radioButton.checked = true;
                        //         }
                        //     }
                        // }

                        const myButton = document.getElementById('backButton');
                        myButton.addEventListener('click', function () {
                            // loadDataFromFirstPage()
                        });
                    }

                    // show questions right away
                    showQuestions(questions, quizContainer);

                    // on submit, show results
                    submitButton.onclick = function () {
                        showResults(questions, quizContainer, resultsContainer);
                    };
                }

                submitButton.addEventListener("click", function () {
                    console.log('event listener1...')
                    firstPageDataToLocalStorage()
                    loadDataFromSecondPage();
                })

                function firstPageDataToLocalStorage() {
                    console.log('in firstPageDataToLocalStorage method......')
                    console.log("all correct answer 1 - " + allCorrectAns1)

                    // localStorage.clear()
                    // console.log('local storage cleared...')
                    localStorage.setItem("allCorrectAns1", JSON.stringify(allCorrectAns1));
                    console.log('saved to local storage...')
                    allCorrectAns1 = [];
                    console.log("array cleared...")

                }


            </script>
            {{--                   Page 3 --}}

            <div id="Page3" style="display:none">
                <div class="row" style="margin-top: -40px">
                    <div class="row mt-5">
                        <div class="col">
                            <div class="col" style="margin-left: 20px;margin-top: -50px">
                                <span class=" fw-semibold" style="color:#972F15;font-size: 17px">This section has four
                                    sections with 10
                                    questions in each section to assess Sinhala language
                                    proficiency, ability to read Sinhala words written in English letters, prior knowledge
                                    in hate
                                    speech
                                    identification, comprehension, and analytical skills.</span>
                            </div>

                        </div>
                    </div>
                    <div class="col">
                        <img src="{{ asset('images/section 1B.png') }}" width="300px" height="auto" class="p-0"
                        />
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 2G.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -100px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 3B.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -100px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 4B.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -117px"/>
                    </div>
                </div>
                <div class="row" style="margin-top: -100px;width: 1268px; margin-left: -102px">

                    <div class="col fw-bold" style="margin-left: 160px">
                        <span>Sinhala Language Proficiency</span>
                    </div>
                    <div class="col fw-bold" style="margin-left: -570px;text-align: center">
                        <span>Ability to read Sinhala words <br> written in English</span>

                    </div>
                    <div class="col fw-bold" style="margin-left: -380px;text-align: center">
                        <span>Prior Knowledge in Hate <br> Speech Identification</span>
                    </div>
                    <div class="col fw-bold" style="margin-left: -440px;text-align: center">
                        <span style="margin-left: 200px">Sinhala Comprehension and Analytical Skills</span>
                    </div>

                </div>

                <div class="col">
                    <div class="col" style="margin-left: 20px;margin-top: 40px;text-align: center">
                        <span class=" fw-semibold" style="color:#c00219;font-size: 17px">Please answer all questions check
                            your fit to start the journey in UOM-CROWD</span>
                    </div>
                    <div class="col" style="margin-left: 20px;margin-top: 40px;text-align: center">
                        <span class=" fw-semibold" style="font-size: 17px">Select the correct Sinhala word/phrase written
                            in English letter</span>
                    </div>
                    <div class="col" style="margin-left: 20px;margin-top: 40px;text-align: start">
                        <span class=" fw-semibold" style="font-size: 17px">ඉංග්‍රීසි අකුරින්‌ ලියා ඇති නිවැරදි සිංහල
                            වචනය/වාක්ය ඛණ්ඩය තෝරන්න.</span>
                    </div>
                </div>

                <div id="quiz3"></div>
                {{--                <button id="submit3">Get Results</button>--}}
                <div id="results3"></div>

                <div class="col">
                    <div class="mt-3" style="margin-left: 165px">
                        <a href="" onclick="return show('Page4','Page1','Page2','Page3','Page5');">
                            <button type="button" class="btn btn btn-lg rounded-0 mt-4" id="submit3"
                                    style="background-color: #972F15;color: white;margin-left: 800px">Next&nbsp;&nbsp;>>
                            </button>
                        </a>
                        <a href="" onclick="return show('Page2','Page1','Page3','Page4','Page5');">
                            <button type="button" id="backButton2" class="btn btn btn-lg rounded-0 mt-4"
                                    style="background-color: #972F15;color: white;margin-left: -1000px">
                                <<&nbsp;&nbsp;Back
                            </button>
                        </a>
                    </div>
                </div>
            </div>

            <script>
                let allCorrectAns2 = [];
                var correctAnswers3;
                var allanswers2 = 0;
                var myQuestions3 = [
                    {
                        question: "(1) Tawa language ekak danagattata paadu wenne naha.",
                        answers: {
                            a: "තව language එකක්‌ දැනගත්තට පාඩු වෙන්නෙ නැහැ.",
                            b: "තව එකක්‌ දැන පාඩු නැහැ",
                            c: "ඔයාගේ දුරකනනයෙන්‌ පාඩු වෙන්නේ නැහැ"
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: "(2) karunakarala mata sanasillay inna denna.",
                        answers: {
                            a: "කරුණාකරලා මට සැනසිල්ලේ ඉන්න දෙන්න.",
                            b: "කරුණාකරලා සැනසිල්ලේ දෙන්න",
                            c: "කරුණාවෙන්‌ ඝවන්‌ දෙන්න"
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: "(3) oya math ekka poddak natanna kamathida?",
                        answers: {
                            a: "ඔයා මාත්‌ එක්ක පොඩ්ඩක් නටන්න කැමනිද",
                            b: "ඔයා නටන්න කැමනිද",
                            c: "ඔයා මාත්‌ එක්ක එනවද"
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(4) oba sinhala katha karanavadha?",
                        answers: {
                            a: "ඔබ සිංහල කතා කරනවද",
                            b: "ඔබ කතා කරනවා",
                            c: "ඔයා සිංහල කතා කරනවද"
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(5) mata obava therum ganna baha",
                        answers: {
                            a: "මට ඔබව තේරුම් ගන්න බැහැ",
                            b: "මට තේරුම්‌ ගනු බෑ",
                            c: "මට තේරුම් ගන්න බෑ ඔබව"
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(6) sadarayen piligannawa",
                        answers: {
                            a: "සාදරයෙන්‌ පිලිගන්නවා",
                            b: "සාදරයෙන්‌ පළිගන්නවා",
                            c: "ඔබව මම සාදරයෙන්‌ පිලිගන්නවා"
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(7) Anna araya huu kiyanawa",
                        answers: {
                            a: "අන්න අරයා හූ කියනවා",
                            b: "අන්න හූ කියනවා",
                            c: "අරයට හූ කියන්න"
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(8) Rata hadana sawbhaagyaye dakma",
                        answers: {
                            a: "රට හදන සව්භාග්‍යයේ දැක්ම",
                            b: "රට සෞභාග්‍යය දැක්ම",
                            c: "රට හදන්න අන්යවශ්යයි"
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(9) Uthsawa sabhawa amatamin janadhipathi apekshaka uthsawa sabhawa amathiya",
                        answers: {
                            a: "උත්සව සභාව අමතමින්‌ ජනාධිපති අපේක්ෂක උත්සව සභාව අමතයි",
                            b: "උත්සවය අමතා ජනාධිපති අමතයි",
                            c: "උත්සව සභාව අමතන්න අවශ්ශ්යයි"
                        },
                        correctAnswer: "a",
                    }, {
                        question: "(10) Lankawe anka eke wyapaarikaya",
                        answers: {
                            a: "ලංකාවේ අංක එකේ ව්‍යාපාරිකයා",
                            b: "ලංක ව්‍යාපාරික",
                            c: "අංක එකේ ව්‍යාපාරික ප්‍රජාව"
                        },
                        correctAnswer: "a",
                    },

                ];

                var quizContainer = document.getElementById("quiz3");
                var resultsContainer = document.getElementById("results3");
                var submitButton = document.getElementById("submit3");

                generateQuiz(myQuestions3, quizContainer, resultsContainer, submitButton);

                function generateQuiz(
                    questions,
                    quizContainer,
                    resultsContainer,
                    submitButton
                ) {
                    function showQuestions3(questions, quizContainer) {
                        // we'll need a place to store the output and the answer choices
                        var output = [];
                        var answers;

                        // for each question...
                        for (var i = 0; i < questions.length; i++) {
                            // first reset the list of answers
                            answers = [];

                            // for each available answer...
                            for (letter in questions[i].answers) {
                                // ...add an html radio button
                                answers.push(
                                    "<label>" + '<input type="radio" name="question' + (i+10) + '" value="' + letter + '">' + letter + ": " + questions[i].answers[letter] + "</label>"
                                );
                            }

                            // add this question and its answers to the output
                            output.push(
                                '<div class="row mt-4">' +
                                '   <div class="col fs-4">' +
                                '<span class="question">' +
                                questions[i].question +
                                '</span>' +
                                "</div>" +
                                '<div class="row fs-5 p-4 answers">' +
                                answers.join("") +
                                "</div>"
                            );
                        }

                        // finally combine our output list into one string of html and put it on the page
                        quizContainer.innerHTML = output.join("");
                    }

                    function showResults(questions, quizContainer, resultsContainer) {
                        // gather answer containers from our quiz
                        var answerContainers = quizContainer.querySelectorAll(".answers");

                        // keep track of user's answers
                        var userAnswer = "";
                        var numCorrect = 0;

                        localStorage.setItem("allCorrectAns2", JSON.stringify(allCorrectAns2));
                        console.log("added to local allCorrectAns2")
                        // for each question...
                        for (var i = 0; i < questions.length; i++) {
                            // find selected answer
                            userAnswer = (
                                answerContainers[i].querySelector(
                                    "input[name=question" + (i+10) + "]:checked"
                                ) || {}
                            ).value;
                            console.log("userAnswer//////////////////////////")
                            console.log(userAnswer)
                            allCorrectAns2.push(userAnswer);
                            console.log("pushed data to allCorrectAns2")
                            if (userAnswer == "a" || userAnswer == "b" || userAnswer == "c" || userAnswer == "d" || userAnswer == "e" || userAnswer == "f") {
                                allanswers2++;
                                // if answer is correct
                                if (userAnswer === questions[i].correctAnswer) {
                                    // add to the number of correct answers
                                    numCorrect++;

                                    // color the answers green
                                    // answerContainers[i].style.color = "lightgreen";
                                }
                                // if answer is wrong or blank
                                else {
                                    // color the answers red
                                    // answerContainers[i].style.color = "red";
                                }
                            }
                        }


                        console.log("All ANswers are2 :", allanswers2);
                        correctAnswers3 = numCorrect;
                        // show number of correct answers out of total
                        // resultsContainer.innerHTML =
                        //     numCorrect + " out of " + questions.length;
                    }


                    // function loadDataFromSecondPage() {
                    //     console.log('loadDataFromSecondPage method')
                    //     var savedAnswers = JSON.parse(localStorage.getItem("allCorrectAns2"));
                    //     console.log("allCorrectAns2 "+savedAnswers);
                    //
                    //     // Loop through each saved answer and set the corresponding radio button
                    //     for (let i = 0; i < savedAnswers.length; i++) {
                    //
                    //         // Get the radio button with the matching value
                    //         let radioButton = document.querySelector('input[type="radio"][name="question'+i+'"][value="'+savedAnswers[i]+'"]');
                    //
                    //         // If the radio button exists, set it as checked
                    //         if (radioButton) {
                    //             console.log("in if...")
                    //             radioButton.checked = true;
                    //         }
                    //     }
                    // }

                    function loadDataFromFirstPage() {
                        console.log('loadDataFromFirstPage method')
                        var savedAnswers = JSON.parse(localStorage.getItem("allCorrectAns1"));
                        console.log("allCorrectAns1 " + savedAnswers);

                        // Loop through each saved answer and set the corresponding radio button
                        for (let i = 0; i < savedAnswers.length; i++) {

                            // Get the radio button with the matching value
                            let radioButton = document.querySelector('input[type="radio"][name="question' + i + '"][value="' + savedAnswers[i] + '"]');

                            // If the radio button exists, set it as checked
                            if (radioButton) {
                                console.log("in if...")
                                radioButton.checked = true;
                            }
                        }
                    }

                    const backButton2 = document.getElementById('backButton2');
                    backButton2.addEventListener('click', function () {
                        loadDataFromFirstPage()
                    });

                    // show questions right away
                    showQuestions3(questions, quizContainer);

                    // on submit, show results
                    submitButton.onclick = function () {
                        showResults(questions, quizContainer, resultsContainer);
                    };
                }

                submitButton.addEventListener("click", function () {
                    console.log('event listener2...')
                    secondPageDataToLocalStorage()
                })

                function secondPageDataToLocalStorage() {
                    console.log('in secondPageDataToLocalStorage method2......')
                    console.log("all correct answer 2 - " + allCorrectAns2)

                    // localStorage.clear()
                    // console.log('local storage cleared...')
                    localStorage.setItem("allCorrectAns2", JSON.stringify(allCorrectAns2));
                    console.log('saved to local storage...')
                    allCorrectAns2 = [];
                    console.log("array cleared...")

                }

                // Get the saved answers from local storage
                var savedAnswers = JSON.parse(localStorage.getItem("allCorrectAns1"));

                // Loop through the questions
                for (var i = 0; i < myQuestions.length; i++) {
                    console.log('in f...')
                    var answers = [];

                    // Loop through the answers and create radio buttons
                    for (var letter in myQuestions[i].answers) {
                        var isChecked = (savedAnswers && savedAnswers[i] == letter); // Check if this answer was previously selected
                        var inputHtml = '<input type="radio" name="question' + i + '" value="' + letter + '"';
                        if (isChecked) inputHtml += ' checked';
                        inputHtml += '>';

                        // Add the radio button to the answer array
                        answers.push(
                            "<label>" + inputHtml + letter + ": " + myQuestions[i].answers[letter] + "</label>"
                        );
                    }

                    // Add the answers to the HTML element
                    document.getElementById("question" + i).innerHTML = answers.join("<br>");
                }

            </script>

            {{--                        PAGE 4 --}}

            <div id="Page4" style="display:none">
                <div class="row" style="margin-top: -40px">
                    <div class="row mt-5">
                        <div class="col">
                            <div class="col" style="margin-left: 20px;margin-top: -50px">
                                <span class=" fw-semibold" style="color:#972F15;font-size: 17px">This section has four
                                    sections with 10
                                    questions in each section to assess Sinhala language
                                    proficiency, ability to read Sinhala words written in English letters, prior knowledge
                                    in hate
                                    speech
                                    identification, comprehension, and analytical skills.</span>
                            </div>

                        </div>
                    </div>
                    <div class="col">
                        <img src="{{ asset('images/section 1B.png') }}" width="300px" height="auto" class="p-0"
                        />
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 2B.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -100px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 3G.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -100px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 4B.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -117px"/>
                    </div>
                </div>
                <div class="row" style="margin-top: -100px;width: 1268px; margin-left: -102px">

                    <div class="col fw-bold" style="margin-left: 160px">
                        <span>Sinhala Language Proficiency</span>
                    </div>
                    <div class="col fw-bold" style="margin-left: -570px;text-align: center">
                        <span>Ability to read Sinhala words <br> written in English</span>

                    </div>
                    <div class="col fw-bold" style="margin-left: -380px;text-align: center">
                        <span>Prior Knowledge in Hate <br> Speech Identification</span>
                    </div>
                    <div class="col fw-bold" style="margin-left: -440px;text-align: center">
                        <span style="margin-left: 200px">Sinhala Comprehension and Analytical Skills</span>
                    </div>

                </div>

                <div class="col">
                    <div class="col" style="margin-left: 20px;margin-top: 40px;text-align: center">
                        <span class=" fw-semibold" style="color:#c00219;font-size: 17px">Please answer all questions check
                            your fit to start the journey in UOM-CROWD</span>
                    </div>
                    <div class="col" style="margin-left: 0px;margin-top: 40px;text-align: start">
                        <span class=" fw-semibold" style="font-size: 17px">Assess the knowledge on Hate Speech</span>
                    </div>
                    <div class="col" style="margin-top: 40px;text-align: start">
                        <span class=" fw-semibold" style="font-size: 17px"> වෛරී කථණය පිළිබඳ දැනුම තක්සේරු කරන්න.</span>
                    </div>
                    <div class="col" style="margin-top: 10px;text-align: start">
                        <span class=" fw-semibold" style="font-size: 17px">These questions are also mentioned in English
                            language for the convenience of the
                            service providers (Contributors) who have proficiency in English language.</span>
                    </div>
                    <div class="col" style="margin-top: 10px;text-align: start">
                        <span class=" fw-semibold" style="font-size: 17px">Some of the excerpts from the social media
                            posts may be emotional and provocative.</span>
                    </div>
                    <div class="col" style="margin-top: 30px;text-align: start">
                        <span class=" fw-semibold" style="font-size: 17px"> ඉංග්‍රීසි භාෂාවෙහි නිපුනන්වයක්‌ ඇති සේවා
                            සපයන්නන්‌ (Contributors) ගේ පහසුව සඳහා ඉංග්‍රීසි භාෂාවෙන්ද මෙම ප්රශ්න සඳහන්‌ කර ඇත. සමාජ මාධිය
                            දැන්වීම වලින්‌ උපුටා ගන්නාලද කරුණු සමහරක්‌ ආවේගශීලි හා ජරකෝපමකාරී විය හැකිය.</span>
                    </div>
                    <div class="col" style="margin-top: 30px;text-align: start">
                        <span class=" fw-semibold" style="font-size: 17px">Read to learn / කියවා ඉගෙන ගන්න <br> <a
                                rel="stylesheet"
                                href="https://does.google.com/document/d/1NLSztVoH6-SSvkRWCGplF FiewOM-If4iUXWABIMGOzE/edit?usp=sharing">https://does.google.com/document/d/1NLSztVoH6-SSvkRWCGplF
                                FiewOM-If4iUXWABIMGOzE/edit?usp=sharing </a></span>
                    </div>
                    <div class="col" style="margin-top: 30px;text-align: start">
                        <span class=" fw-semibold" style="font-size: 17px">How familiar are you with hate speech and
                            related issues? To find out, answer our quiz.</span>
                        <br>
                        <span class=" fw-semibold" style="font-size: 17px">වෛරී ප්‍රකාශය සහ ඒ ආශ්‍රිත ගැටලු පිළිබඳව ඹබ
                            කෙතරම්‌ හුරුපුරුදුද? සොයා ගැනීමට, අපගේ ප්‍රශ්නාවලිය ට පිළිතුරු ලබා දෙන්න.</span>
                    </div>
                </div>


                <div id="quiz4"></div>
                <div id="results4"></div>

                <div class="col">
                    <div class="mt-3" style="margin-left: 165px">
                        <a href="" onclick="return show('Page5','Page1','Page2','Page3','Page4');">
                            <button type="button" class="btn btn btn-lg rounded-0 mt-4" id="submit4"
                                    style="background-color: #972F15;color: white;margin-left: 800px">Next&nbsp;&nbsp;>>
                            </button>
                        </a>
                        <a href="" onclick="return show('Page3','Page1','Page2','Page4','Page5');">
                            <button type="button" id="backButton3" class="btn btn btn-lg rounded-0 mt-4"
                                    style="background-color: #972F15;color: white;margin-left: -1000px">
                                <<&nbsp;&nbsp;Back
                            </button>
                        </a>
                    </div>
                </div>
            </div>

            <script>
                let allCorrectAns3 = [];
                var correctAnswers4;
                var allanswers3 = 0;
                var myQuestions4 = [
                    {
                        question: "1. What is true of hate speech, as it is commonly understood? <br>&nbsp;&nbsp;&nbsp;සාමාන්‍යයෙන් තේරුම් ගත හැකි පරිදි වෛරී ප්‍රකාශ සම්බන්ධ සත්‍ය ප්‍රකාශය කුමක්ද?",
                        answers: {
                            a: "It is conveyed through any form of expression - including images, cartoons, memes, art objects, gestures and symbols - and/or media. <br>" +
                                "&nbsp; &nbsp;&nbsp;රූප, කාටූන්‌, Memes, කලා වසනු, අභිනයන්‌ සහ ඝංකේන - සහ/හෝ මාධ්ය ඇතුළුව ඕනෑම ආකාරයක ජ්රකාශනයක්‌ හරහා එය ප්රකාශ කෙරේ.",
                            b: "It is discriminatory and/or pejorative towards an individual, or a group. <br>" +
                                "&nbsp;&nbsp;&nbsp;එය පුද්ගලයෙකුට හෝ කණ්ඩායමකට වෙනඥඝ්‌ කොට සැලකීමක්‌ සහ/හො අපහාසාන්මක වේ.",
                            c: "It makes reference to real, purported or imputed identity factors, such as religion,ethnicity, nationality, race, colour, descent, gender. <br>" +
                                "&nbsp;&nbsp;&nbsp;එය ආගම, වාර්ගිකන්වය, ජානිකන්වය, ජානිය, වර්ණය, සම්භවය, ස්න්රී පුරුෂ භාවය වැනි සැබැ, අරමුණු කරගන්‌ හෝ ආරෝපණය කරන ලද අනාන්යනා සාධක වෙන යොමු කරයි.",
                            d: "All of the above <br>" +
                                "&nbsp;&nbsp;&nbsp;ඉහන සියල්ලම"
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: "2. According to the United Nations definition, what “identity factor(s)” must hate speech refer to in a discriminatory and/or pejorative way? <br> &nbsp;&nbsp;&nbsp;එක්සන්‌ ජාතීන්ගේ නිර්වචනයට අනුව, වෛරී කථනය වෙනස්‌ කොට සැලකීමේ සහ/හෝ නින්දිත ආකාරයෙන්‌ සඳහන්‌ කළ යුනු “අනන්යනා සාධක(ය)” මොනවාද?",
                        answers: {
                            a: "Only religion, ethnicity, nationality, race, colour, descent, and/or gender. <br>" +
                                "&nbsp; &nbsp;&nbsp;ආගම, වාර්ගිකන්වය, ජානිකන්වය, ජානිය, වර්ණය, සම්භවය, සහ/හෝ ස්න්රී පුරුෂ භාවය පමණි.",
                            b: "At least 2 of the following: religion, ethnicity, nationality, race, colour, descent,and/or gender <br>" +
                                "&nbsp;&nbsp;&nbsp;පහන සඳහන්‌ අවම වශයෙන්‌ 2: ආගම, වාර්ගිකන්වය, ජානිකන්වය, ජානිය, වර්ණය, සමීිභවය, සහ/හෝ ස්ත්‍රී පුරුෂ භාවය",
                            c: "Any characteristics conveying identity in a broad sense, such as religion, ethnicity, nationality, race, colour, descent, gender, but also language, economic or social origin, disability, health status, or sexual orientation and any other identity factors. <br>" +
                                "&nbsp;&nbsp;&nbsp;ආගම, වාර්ගිකන්වය, ජානිකන්වය, ජානිය, වර්ණය, සම්භවය, සඝ්න්රී පුරුෂ භාවය, නමුන්‌ භාෂාව, ආර්ථික හෝ සමාජ සම්භවය, ආබාධින තත්වය, සෞඛ්ය තත්වය හෝ ලිංගික දිශානනිය සහ වෙනන්‌ අනන්යනා සාධක වැනි පුළුල්‌ අර්ථයකින්‌ අනන්යනාව ප්රකාශ කරන ඕනෑම ලක්ෂණයක්",
                            d: "None - speech need not reference any identity factor to be considered hateful <br>" +
                                "&nbsp;&nbsp;&nbsp;කිසිවක්‌ නැන - කථනය ද්වේශ සඟගන ලෙස සැලකීමට කිසිදු අනන්යනා සාධකයක්‌ සඳහන්‌ කිරීම අවශ්ය නොවේ."
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: "3. According to the United Nations, who can be targeted by hate speech?<br> &nbsp;&nbsp;&nbsp;එක්සන්‌ ජාතීන්ගේ සංවිධානයට අනුව, වෛරී ප්රකාශ මගින්‌ ඉලක්ක කළ හැක්කේ කාටද?",
                        answers: {
                            a: "States and their offices and symbols, public officials, religious leaders, or tenets of faith.<br>" +
                                "&nbsp; &nbsp;&nbsp;රාජ්යයන්‌ සහ ඒවායේ කාර්යාල සහ සංකේන, රාජ්ය නිලධාරීන්‌, ආගමික නායකයන්‌, හෝ පුද්ගලයෙකු හෝ, බොහෝ විට, පුද්ගල කණ්ඩායමක්‌ විසින්‌ ගරු කරනු ලබන මූලධර්මයක්‌ හෝ විශ්වාසයක්.",
                            b: "At least 2 of the following: religion, ethnicity, nationality, race, colour, descent,and/or gender <br>" +
                                "&nbsp;&nbsp;&nbsp;පහත සඳහන්‌ අවම වශයෙන්‌ 2: ආගම, වාර්ගිකන්වය, ජානිකන්වය, ජානිය, වර්ණය, සමීිභවය, සහ/හෝ ස්ත්‍රී පුරුෂ භාවය",
                            c: "Minority groups only.<br>" +
                                "&nbsp;&nbsp;&nbsp;සුළු ජානික කණ්ඩායම්‌ පමණයි.",
                            d: "All of the above. <br>" +
                                "&nbsp;&nbsp;&nbsp;ඉහන සියල්ලම."
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: "4. Online hate speech can contribute to causing real harm.<br> &nbsp;&nbsp;&nbsp;පරිගණකයකින්‌ පාලනය වන හෝ සම්බන්ධ කර සිදු කරන වෛරී කථනය සැබෑ හානියක්‌ කිරීමට දායක විය හැක.",
                        answers: {
                            a: "True<br>" +
                                "&nbsp; &nbsp;&nbsp;නිවැරදි",
                            b: "False<br>" +
                                "&nbsp;&nbsp;&nbsp;වැරදි",

                        },
                        correctAnswer: "a",
                    },
                    {
                        question: "5. What are some of the ways to tackle hate speech recommended by the Strategy and Plan of Action on Hate Speech?<br> &nbsp;&nbsp;&nbsp;වෛරී කථනය පිළිබඳ උපාය මාර්ගය සහ ක්රියාකාරී සැලැස්ම මගින්‌ නිර්දේශ කර ඇනි වෛරී ප්රකාශය මැඩලීමේ ක්රම මොනවාද?",
                        answers: {
                            a: "Monitor and analyze hate speech<br>" +
                                "&nbsp; &nbsp;&nbsp;වෛරී කථනය නිරීක්ෂණය කිරීම සඟ විශ්ලේෂණය කිරීම",
                            b: "Address root causes, drivers and actors of hate speech<br>" +
                                "&nbsp;&nbsp;&nbsp;වෛරී ප්‍රකාශයේ මූල හේතු, ගෙන යන්නන්‌ සහ ක්‍රියාකාරීන් අමතන්න.",
                            c: "Engage and support the victims. <br>" +
                                "&nbsp;&nbsp;&nbsp;  වින්දිනයින්‌ හෝ ගොදුරු වූ පුද්ගලයන්‌ සමඟ සම්බන්ධ වී සහය වන්න.",
                            d: "Use education as a preventive tool.  <br>" +
                                "&nbsp;&nbsp;&nbsp;වැළැක්වීමේ මෙවලමක්‌ ලෙස අධ්යාපනය භාවිනා කරන්න.",
                            e: "All of the above.  <br>" +
                                "&nbsp;&nbsp;&nbsp;ඉහන සියල්ලම.",
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: "6. Fighting hate speech is the responsibility of<br> &nbsp;&nbsp;&nbsp;වෛර්‌ කථනයට එරෙහිව සටන්‌ කිරීම වගකීම වන්නේ",
                        answers: {
                            a: "Government<br>" +
                                "&nbsp; &nbsp;&nbsp;ආණ්ඩුව",
                            b: "Targets of hate speech<br>" +
                                "&nbsp;&nbsp;&nbsp;වෛරී ප්‍රකාශයේ ඉලක්ක.",
                            c: "Engage and support the victims. <br>" +
                                "&nbsp;&nbsp;&nbsp;  වින්දිනයින්‌ හෝ ගොදුරු වූ පුද්ගලයන්‌ සමඟ සම්බන්ධ වී සහය වන්න.",
                            d: "The United Nations <br>" +
                                "&nbsp;&nbsp;&nbsp;එක්සන්‌ ජානීන්ගේ සංවිධානය",
                            e: "Social media platforms.  <br>" +
                                "&nbsp;&nbsp;&nbsp;සමාජ මාධ්ය වේදිකා",
                            f: "All of us  <br>" +
                                "&nbsp;&nbsp;&nbsp;අපි හැමෝම",
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: "7. Abusive or indecent comments on social media are hate speech even if they are not targeted at a person or organization.<br> &nbsp;&nbsp;&nbsp;අපවාදාන්මක හෝ අශික්ෂන යෙදීම්‌ සඳහන්‌ සමාජ මාඨ්‍යයෙහි පලවෙන ප්‍රකාශ පුද්ගලයකු හෝ ආයතනයක් ඉලක්ක කොට නොගන්නද වෛරී ප්‍රකාශයක් වේ",
                        answers: {
                            a: "Yes<br>" +
                                "&nbsp; &nbsp;&nbsp;ඔව්",
                            b: "No<br>" +
                                "&nbsp;&nbsp;&nbsp;නැත",
                            c: "May be<br>" +
                                "&nbsp;&nbsp;&nbsp;විය හැක."
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: "8. Hate groups describe 'the other' in ways that emphasize difference, making them seem alien" +
                            "and even subhuman. This is often done through caricatures or name tape associations or" +
                            "ideologies. In some cases, hate groups will claim that others are not really human." +
                            "<br> Indicate whether you agree with this statement.<br>වෛරී කණ්ඩායම්‌ අනෙකා විස්තර කරන්නේ ඔවින්‌ ආගන්තුකයන්‌ මෙන්ම අමනුෂ්යයන්‌ ලෙස පවා" +
                            " පෙනෙන්නට සලස්වමින්‌ වෙනස්කම්‌ අවධාරණය වන ආකාරවලට බවයි. මෙය බොහෝ විට" +
                            "කෙරෙන්නේ විකට චින්ර හෝ නම්‌ පට බැදීම්‌ හෝ මනවාද මගිනි. සමඟර අවස්නාවලදී වෛරී" +
                            "කණ්ඩායම්‌ අනෙකුන්‌ සැබවින්ම මිනිසුන්‌ නොවේ යැයි ප්රකාශ කරනු ඇන." +
                            " <br>ඔබ මෙම ප්රකාශයට එකඟ වේදැයි සඳහන්‌ කරන්න.",
                        answers: {
                            a: "Agree<br>" +
                                "&nbsp; &nbsp;&nbsp;එකඟ වේ.",
                            b: "| don’t agree<br>" +
                                "&nbsp;&nbsp;&nbsp;එකඟ නොවේ."
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: "9. Following are some of the social media posts. This is not hate speech.<br> &nbsp;&nbsp;&nbsp;පහන සඳහන්‌ වන්නේ සමාජ මාධ්ය ජාලාවෙහි පල කිරීම්‌ කිහිපයකි. මින්‌ වෛරී ප්රකාශයක් නොව්න්නේ",
                        answers: {
                            a: "ඬලස්‌ නැමනි කුණු අපුල්ලන්නාට, නැගෙනහිර හම්බයොන්ගේ දරුවන්ට අන්නවාදය හැදෑරීම විශ්ව විද්යාල හැදීමට මුදල්වලට කෑදර වී මුලිකවූ නමුන්නාන්සේ සිංහල දරුවෙකු මරා දැමු විට ඒක 69590 ඞාරණය කරන අපූරුව. ලැජ්ජයි මහන්නයෝ නමුන්නාන්සේ ගැන. කටට පණුවෝ ගහනවා ඕයි මේ කියන කනාවලට.",
                            b: "රජය මේ සේලාම්‌ පිළිලය වැඩි වීමට පෙර නීනි සකස්‌ කල යුතුය. මේ රටේ මහ ජානියට වින කරන" +
                                "කක්කුසියක්‌ පවා ටික දිනකින්‌ පල්ලි කර ගන්නා ඉස්ලාම්‌ අන්නවාදීන්‌ මර්දනය කළ යුනුය." +
                                "නැනහොත්‌ අනාගනයේ මීට වඩා දරුණු ගැටුම්‌ ඇනි විය හැකිය. ",
                            c: "බංගලිදේශ හම්බයෙක්‌ හාමුදුරුවන්ට ගහන හැටි පේනවද? අපේ සමහර පොන්නයෝ කියනවා හැම" +
                                "ආගමකින්ම කියන්නේ හොඳක්‌ කියලා.",
                            d: "රටේ පවනින විවිධ ජානීන්ට ප්රමුඛ නාවය දීමේ වැඩ පිළිවලට විරුද්ධ නාවය දැක්වීම සඳහා නව නීනි වල අවශ්යනාව පෙන්වා දීම සඳහා රටෙහි සමසඝ්න ජනනාව පෙළ ගැසිය යුතුය."

                        },
                        correctAnswer: "a",
                    }, {
                        question: "10. Which of the following factors affect the detection of hate speech?<br> &nbsp;&nbsp;&nbsp;වෛරී ප්රකාශ හඳුනා ගැනීම සඳහා පහන සඳහන්‌ කුමන කරුණු බලපායිද?",
                        answers: {
                            a: "The social class in which they live <br>" +
                                "&nbsp;&nbsp;&nbsp; තමන්‌ ජීවන්වන සමාජ ස්ථරය",
                            b: "His own beliefs <br>" +
                                "&nbsp;&nbsp;&nbsp; තමාගේ විශ්වාසයන්",
                            c: "Their core principles <br>" +
                                "&nbsp;&nbsp;&nbsp; තමන්‌ ගේ හර පද්දනීන්",
                            d: "own bias <br>" +
                                "&nbsp;&nbsp;&nbsp; තමගේ පක්ෂග්රාභීන්වය",
                            e: "All of the above <br>" +
                                "&nbsp;&nbsp;&nbsp; ඉහන සියල්ල",

                        },
                        correctAnswer: "a",
                    },

                ];

                var quizContainer = document.getElementById("quiz4");
                var resultsContainer = document.getElementById("results4");
                var submitButton = document.getElementById("submit4");

                generateQuiz(myQuestions4, quizContainer, resultsContainer, submitButton);

                function generateQuiz(
                    questions,
                    quizContainer,
                    resultsContainer,
                    submitButton
                ) {
                    function showQuestions4(questions, quizContainer) {
                        // we'll need a place to store the output and the answer choices
                        var output = [];
                        var answers;

                        // for each question...
                        for (var i = 0; i < questions.length; i++) {
                            // first reset the list of answers
                            answers = [];

                            // for each available answer...
                            for (letter in questions[i].answers) {
                                // ...add an html radio button
                                answers.push(
                                    "<label>" + '<input type="radio" name="question' + (i+20) + '" value="' + letter + '">' + letter + ": " + questions[i].answers[letter] + "</label>"
                                );
                            }

                            // add this question and its answers to the output
                            output.push(
                                '<div class="row mt-4">' +
                                '   <div class="col fs-4">' +
                                '<span class="question">' +
                                questions[i].question +
                                '</span>' +
                                "</div>" +
                                '<div class="row fs-5 p-4 answers">' +
                                answers.join("") +
                                "</div>"
                            );
                        }

                        // finally combine our output list into one string of html and put it on the page
                        quizContainer.innerHTML = output.join("");
                    }

                    function showResults(questions, quizContainer, resultsContainer) {
                        // gather answer containers from our quiz
                        var answerContainers = quizContainer.querySelectorAll(".answers");

                        // keep track of user's answers
                        var userAnswer = "";
                        var numCorrect = 0;

                        localStorage.setItem("allCorrectAns3", JSON.stringify(allCorrectAns3));
                        console.log("added to local allCorrectAns3")
                        // for each question...
                        for (var i = 0; i < questions.length; i++) {
                            // find selected answer
                            userAnswer = (
                                answerContainers[i].querySelector(
                                    "input[name=question" + (i+20) + "]:checked"
                                ) || {}
                            ).value;
                            allCorrectAns3.push(userAnswer);
                            console.log("pushed data to allCorrectAns3")
                            if (userAnswer == "a" || userAnswer == "b" || userAnswer == "c" || userAnswer == "d" || userAnswer == "e" || userAnswer == "f") {
                                allanswers3++;
                                // if answer is correct
                                if (userAnswer === questions[i].correctAnswer) {
                                    // add to the number of correct answers
                                    numCorrect++;

                                    // color the answers green
                                    // answerContainers[i].style.color = "lightgreen";
                                }
                                // if answer is wrong or blank
                                else {
                                    // color the answers red
                                    // answerContainers[i].style.color = "red";
                                }
                            }
                        }

                        console.log("All ANswers are3 : ", allanswers3);

                        correctAnswers4 = numCorrect;
                        // show number of correct answers out of total
                        // resultsContainer.innerHTML =
                        //     numCorrect + " out of " + questions.length;
                    }

                    // show questions right away
                    showQuestions4(questions, quizContainer);

                    // on submit, show results
                    submitButton.onclick = function () {
                        showResults(questions, quizContainer, resultsContainer);
                    };
                }

                function loadDataFromSecondPage() {
                    console.log('loadDataFromSecondPage method')
                    var savedAnswers = JSON.parse(localStorage.getItem("allCorrectAns2"));
                    console.log("allCorrectAns2 " + savedAnswers);

                    // Loop through each saved answer and set the corresponding radio button
                    for (let i = 0; i < savedAnswers.length; i++) {
                        console.log(savedAnswers[i])
                        // Get the radio button with the matching value
                        let radioButton = document.querySelector('input[type="radio"][name="question' + (i+10) + '"][value="' + savedAnswers[i] + '"]');

                        // If the radio button exists, set it as checked
                        if (radioButton) {
                            console.log("in if...")
                            radioButton.checked = true;
                        }
                    }
                }

                const backButton3 = document.getElementById('backButton3');
                backButton3.addEventListener('click', function () {
                    loadDataFromSecondPage()
                });

                submitButton.addEventListener("click", function () {
                    console.log('event listener2...')
                    thirdPageDataToLocalStorage()
                })

                function thirdPageDataToLocalStorage() {
                    console.log('in thirdPageDataToLocalStorage method3......')
                    console.log("all correct answer 3 - " + allCorrectAns3)

                    // localStorage.clear()
                    // console.log('local storage cleared...')
                    localStorage.setItem("allCorrectAns3", JSON.stringify(allCorrectAns3));
                    console.log('saved to local storage...')
                    allCorrectAns3 = [];
                    console.log("array cleared...")

                }


            </script>
            {{--                            PAGE 5 --}}

            <div id="Page5" style="display:none">
                <div class="row" style="margin-top: -40px">
                    <div class="row mt-5">
                        <div class="col">
                            <div class="col" style="margin-left: 20px;margin-top: -50px">
                                <span class=" fw-semibold" style="color:#972F15;font-size: 17px">This section has four
                                    sections with 10
                                    questions in each section to assess Sinhala language
                                    proficiency, ability to read Sinhala words written in English letters, prior knowledge
                                    in hate
                                    speech
                                    identification, comprehension, and analytical skills.</span>
                            </div>

                        </div>
                    </div>
                    <div class="col">
                        <img src="{{ asset('images/section 1B.png') }}" width="300px" height="auto" class="p-0"
                        />
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 2B.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -100px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 3B.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -100px"/>
                        <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                             style="margin-left: -100px"/>


                        <img src="{{ asset('images/section 4G.png') }}" width="320px" height="auto" class="p-0"
                             style="margin-left: -117px"/>
                    </div>
                </div>
                <div class="row" style="margin-top: -100px;width: 1268px; margin-left: -102px">

                    <div class="col fw-bold" style="margin-left: 160px">
                        <span>Sinhala Language Proficiency</span>
                    </div>
                    <div class="col fw-bold" style="margin-left: -570px;text-align: center">
                        <span>Ability to read Sinhala words <br> written in English</span>

                    </div>
                    <div class="col fw-bold" style="margin-left: -380px;text-align: center">
                        <span>Prior Knowledge in Hate <br> Speech Identification</span>
                    </div>
                    <div class="col fw-bold" style="margin-left: -440px;text-align: center">
                        <span style="margin-left: 200px">Sinhala Comprehension and Analytical Skills</span>
                    </div>

                </div>

                <div class="col">
                    <div class="col" style="margin-left: 20px;margin-top: 40px;text-align: center">
                        <span class=" fw-semibold" style="color:#c00219;font-size: 17px">Please answer all questions check
                            your fit to start the journey in UOM-CROWD</span>
                    </div>

                </div>

                <div id="quiz5"></div>
                {{--                <button id="submit5">Get Results</button>--}}
                <div id="results5"></div>
                <div class="col">
                    <div class="mt-3" style="margin-left: 165px">
{{--                        <a href="#">--}}
                            <button type="button" class="btn btn btn-lg rounded-0 mt-4" id="submit5"
                                    style="background-color: #972F15;color: white;margin-left: 800px">Finish
                            </button>
{{--                        </a>--}}
                        <a href="" onclick="return show('Page4','Page1','Page3','Page2','Page5');">
                            <button type="button" id="backButton4" class="btn btn btn-lg rounded-0 mt-4"
                                    style="background-color: #972F15;color: white;margin-left: -1000px">
                                <<&nbsp;&nbsp;Back
                            </button>
                        </a>
                    </div>
                </div>

            </div>

            <script>
                let allCorrectAns4 = [];
                var correctAnswers5;
                var allanswers4 = 0;
                var myQuestions5 = [
                    {
                        question: "1. උපාධි අපේක්ෂකයින්‌ හන්‌ දෙනෙකුගෙන්‌ යුන්‌ කණ්ඩායමකින්‌ (A,B,C,D,E,F,G) හනර දෙනෙකු ශිෂ්‍ය සංගමයට තෝරා ගනු ලැබේ. ඒ සඳහා පහන සඳහන්‌ කොන්දේසි සපුරාලිය යුතුය:" +
                            "<br><br>&nbsp;&nbsp;&nbsp;A,Bහෝ තෝරාගත යුතු නමුන් A සහ B දෙදෙනාම තෝරාගත නොහැක." +
                            "<br>&nbsp;&nbsp;&nbsp;E හෝ F යන දෙදෙනාගෙන්‌ කෙනෙකු තෝරාගත යුතුය, නමුන්‌ E සහ F දෙදෙනාම තෝරාගත නොහැක." +
                            "<br>&nbsp;&nbsp;&nbsp;C තෝරාගත්තේ නැන්නම් E තෝරාගත නොහැක." +
                            "<br>&nbsp;&nbsp;&nbsp;B තෝරාගත්තේ නැන්නම් G තෝරාගත නොහැක." +
                            "<br><br>&nbsp;&nbsp;ශිෂ්ය සංගමයට F තෝරාගත නැති බව අපි දන්නේ නම්‌, ඉහත නිර්ණායක අනුගමනය කරමින්‌ හතර දෙනෙකුගෙන්‌ යුත් විවිධ කණ්ඩායම්‌ කීයක්‌ සෑදිය හැකිද? ",
                        answers: {
                            a: "එකක්‌",
                            b: "දෙකක්‌",
                            c: "තුනක්‌",
                            d: "හනරක්‌",
                            e: "පහක්‌"
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: '(2) පින්තූරවල ඉහළ පේළිය දෙස බලන්න. අනුපිළිවෙලින්‌ ඊළඟට එන්නේ කුමන කොටුවද?' +
                            '<img src="{{ asset('images/q2.jpg') }}" width="620px" height="auto" class="p-0" style="margin-left: 30px"/>',
                        answers: {
                            a: "A",
                            b: "B",
                            c: "C",
                            d: "D",
                            e: "E"
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: '(3) ඊළඟට එන අංකය කුමක්ද? ' +
                            '<br><br>&nbsp;&nbsp;&nbsp;9, 15, 13, 19, 17, 23...',
                        answers: {
                            a: "18",
                            b: "29",
                            c: "19",
                            d: "20",
                            e: "21"
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: '(4) රටාවේ ඊළඟ රෑපය කුමක්ද?' +
                            '<br><br><img src="{{ asset('images/q4.jpg') }}" width="620px" height="auto" class="p-0" style="margin-left: 30px"/>',
                        answers: {
                            a: "A",
                            b: "B",
                            c: "C",
                            d: "D",
                            e: "E"
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: '(5) ජෝර්ජ්‌, එමලි, දියනි සහ ඇන්ජලා වමේ සිට දකුණට අනුපිළිවෙලෙහි පේළියට වාඩි වී සිටිති. ජැනට්‌ එරික්‌ සමඟ ස්ථාන වෙනස්‌ කරයි, පසුව එරික්‌ මාටින්‌ සමඟ ස්ථාන වෙනස කරයි. පේළියේ දකුණු කෙළවරේ සිටින්නේ කවුද?',
                        answers: {
                            a: "ජෝර්ජ්‌",
                            b: "එමලි",
                            c: "දියනි",
                            d: "ඇන්ජලා"
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: '(6) යහළුවන්‌ පිරිසක්‌ මහල්‌ නිවසක විවිධ තට්ටුවල ජීවත් වෙයි. ජනින්‌ අනුරාධිට පහල තට්ටුවේද' +
                            'සමනලී සාරාට උඬ තට්ටුවේද ජීවත් වෙයි. සාරා ඉන්නේ ජනින්ට පහළ තට්ටුවේය. අනුරාධි ජීවන්‌ වෙන්නේ රොජර්‌' +
                            'එක්කය. පීටර්‌ ඉහළම මහලේ ජීවත් වේ. පහළම තට්ටුවේ ජීවන්‌ වන්නේ කවුද?',
                        answers: {
                            a: "ජනින්‌",
                            b: "අනුරාධි",
                            c: "සමනලී",
                            d: "සාරා",
                            e: "රොජර්‌"
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: '(7) මෝටර්‌ රථ පහක්‌ තරගයකට ඉදිරිපත් වෙයි. Honda රථය Mitsubishi එක පසුකෙරුවද Nisan රථය පහු කිරීමට නොහැකි විය. Mini cooper රථය Audi රථය අභිබවා යාමට අසමත් වූ නමුන්‌ Nisan රථය පරදවයි. අවසානයට ආපු රථය කුමක්ද ?',
                        answers: {
                            a: "Honda",
                            b: "Mitsubishi",
                            c: "Nisan",
                            d: "Mini cooper",
                            e: "Audi"
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: '(8) පහත කවිය කියවා පිළිතුරු සපයන්න.' +
                            '<br><br>&nbsp;&nbsp;&nbsp;පොත් කියවන සැම දෙනා' +
                            '<br>&nbsp;&nbsp;&nbsp;නව දැනුමෙන්‌ පිබිදෙනා' +
                            '<br>&nbsp;&nbsp;&nbsp;අලුන්‌ අලුන්‌ දේ තනා' +
                            '<br>&nbsp;&nbsp;&nbsp;ලොව බැබළෙයි තරු මෙනා' +
                            '<br><br>&nbsp;මෙම කවියේ සමස්ත අදහසින්‌ පැවසෙන්නේ',
                        answers: {
                            a: "පොත් කියවීමේ අගය පිළිබඳවය",
                            b: "තරු ලොවේ බැබලීම පිළිබඳවය",
                            c: "අලුත් අලුත් දේ නිර්මාණය පිළිබඳවය",
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: '(9) පහත කවිය කියවා පිළිතුරු සපයන්න.' +
                            '<br><br>&nbsp;&nbsp;&nbsp;අඳුරෙදි නැති - එළියෙදි ඇති' +
                            '<br>&nbsp;&nbsp;&nbsp;මටම හිතැති - මගේම සකි' +
                            '<br><br>&nbsp;මෙම කවියේ සමස්ත අදහසින්‌ පැවසෙන්නේ',
                        answers: {
                            a: "හිත මිතුරා ගැනය",
                            b: "සෙවනැල්ල ගැනය",
                            c: "හිරු ගැනය",
                        },
                        correctAnswer: "a",
                    },
                    {
                        question: '(10) දින පහම පාසල පැවැන්වූ සතියක එක ළඟ දින තුනක්ම සමන්ට පාසල්‌ පැමිණීමට නොහැකි විය. මෙම ජරකාශය අනුව සමන්‌ නිසැකවම පාසල්‌ නොපැමිණි දවස වනුයේ',
                        answers: {
                            a: "බදාදාය",
                            b: "බ්‍රහස්පතින්දා",
                            c: "සිකුරාදාය",
                        },
                        correctAnswer: "a",
                    },

                ];

                var quizContainer = document.getElementById("quiz5");
                var resultsContainer = document.getElementById("results5");
                var submitButton = document.getElementById("submit5");

                let totalCorrectAnswer;

                generateQuiz(myQuestions5, quizContainer, resultsContainer, submitButton);

                function generateQuiz(
                    questions,
                    quizContainer,
                    resultsContainer,
                    submitButton
                ) {
                    function showQuestions5(questions, quizContainer) {
                        // we'll need a place to store the output and the answer choices
                        var output = [];
                        var answers;

                        // for each question...
                        for (var i = 0; i < questions.length; i++) {
                            // first reset the list of answers
                            answers = [];

                            // for each available answer...
                            for (letter in questions[i].answers) {
                                // ...add an html radio button
                                answers.push(
                                    "<label>" + '<input type="radio" name="question' + (i+30) + '" value="' + letter + '">' + letter + ": " + questions[i].answers[letter] + "</label>"
                                );
                            }

                            // add this question and its answers to the output
                            output.push(
                                '<div class="row mt-4">' +
                                '   <div class="col fs-4">' +
                                '<span class="question">' +
                                questions[i].question +
                                '</span>' +
                                "</div>" +
                                '<div class="row fs-5 p-4 answers">' +
                                answers.join("") +
                                "</div>"
                            );
                        }

                        // finally combine our output list into one string of html and put it on the page
                        quizContainer.innerHTML = output.join("");
                    }

                    function showResults(questions, quizContainer, resultsContainer, event) {
                        // gather answer containers from our quiz
                        var answerContainers = quizContainer.querySelectorAll(".answers");

                        // keep track of user's answers
                        var userAnswer = "";
                        var numCorrect = 0;


                        localStorage.setItem("allCorrectAns4", JSON.stringify(allCorrectAns4));
                        console.log("added to local allCorrectAns4")
                        // for each question...
                        for (var i = 0; i < questions.length; i++) {
                            // find selected answer
                            userAnswer = (
                                answerContainers[i].querySelector(
                                    "input[name=question" + (i+30) + "]:checked"
                                ) || {}
                            ).value;
                            console.log(userAnswer)
                            allCorrectAns4.push(userAnswer);
                            console.log("pushed data to allCorrectAns4")
                            if (userAnswer == "a" || userAnswer == "b" || userAnswer == "c" || userAnswer == "d" || userAnswer == "e" || userAnswer == "f") {
                                allanswers4++;

                                // if answer is correct
                                if (userAnswer === questions[i].correctAnswer) {
                                    // add to the number of correct answers
                                    numCorrect++;

                                    // color the answers green
                                    // answerContainers[i].style.color = "lightgreen";
                                }
                                // if answer is wrong or blank
                                else {
                                    // color the answers red
                                    // answerContainers[i].style.color = "red";
                                }
                            }
                        }

                        console.log("All ANswers are 4 : ", allanswers4);

                        console.log("1 is :" + allanswers1 + " 2 is: " + allanswers2 + " 3 is :" + allanswers3 + " 4 is" + allanswers4);

                        correctAnswers5 = numCorrect;
                        totalCorrectAnswer = correctAnswers2 + correctAnswers3 + correctAnswers4 + correctAnswers5;

                        // show number of correct answers out of total
                        // resultsContainer.innerHTML =
                        //     numCorrect + " out of " + questions.length + "  Total Correct Answers: " + totalCorrectAnswer;

                        // resultsContainer.innerHTML = "Page 1 correct answers "+ correctAnswers2 + "\nPage 2 correct answers "+ correctAnswers3 +
                        //     "\nPage 3 correct answers "+ correctAnswers4 + "\nPage 4 correct answers "+ correctAnswers5;


                        if (allanswers1 >= 10 && allanswers2 >= 10 && allanswers3 >= 10 && allanswers4 >= 10) {

                            if (correctAnswers2 >= 1 && correctAnswers3 >= 1 && correctAnswers4 >= 1) {
                                var url = '{{ route('checkYourFit') }}';
                                window.location.href=url;

                            } else {
                                location.reload(true);
                            }
                        }
                        else {
                            alert("Please answer all questions!")
                            event.preventDefault()
                        }

                    }

                    // show questions right away
                    showQuestions5(questions, quizContainer);

                    // on submit, show results
                    submitButton.onclick = function () {
                        showResults(questions, quizContainer, resultsContainer);
                    };
                }

                function loadDataFromThirdPage() {
                    console.log('loadDataFromThirdPage method')
                    var savedAnswers = JSON.parse(localStorage.getItem("allCorrectAns3"));
                    console.log("allCorrectAns3 " + savedAnswers);

                    // Loop through each saved answer and set the corresponding radio button
                    for (let i = 0; i < savedAnswers.length; i++) {
                        console.log(savedAnswers[i])
                        console.log(i)
                        console.log(i+20)
                        // Get the radio button with the matching value
                        let radioButton = document.querySelector('input[type="radio"][name="question' + (i+20) + '"][value="' + savedAnswers[i] + '"]');

                        // If the radio button exists, set it as checked
                        if (radioButton) {
                            console.log("in if...")
                            radioButton.checked = true;
                        }
                    }
                }

                const backButton4 = document.getElementById('backButton4');
                backButton4.addEventListener('click', function () {
                    loadDataFromThirdPage()
                    forthPageDataToLocalStorage()
                });

                function forthPageDataToLocalStorage() {

                    console.log('in forthPageDataToLocalStorage method4......')
                    console.log("all correct answer 4 - " + allCorrectAns4)

                    // localStorage.clear()
                    // console.log('local storage cleared...')
                    localStorage.setItem("allCorrectAns4", JSON.stringify(allCorrectAns4));
                    console.log('saved to local storage...')
                    allCorrectAns4 = [];
                    console.log("array cleared...")

                }


                var finishButton = document.getElementById("submit5");

                function onSubmitButtonClick(event) {
                    // allCorrectAns4 = [];
                    // console.log("array cleared...")
                    event.preventDefault();

                    const savedEmail = localStorage.getItem('email');

                    $.ajax({
                        url: "{{ route('save_correct_answers') }}",
                        type: 'GET',
                        data: {
                            'correct_answers': totalCorrectAnswer,
                            'email':savedEmail
                        }
                    });
                }

                finishButton.addEventListener("click", onSubmitButtonClick);


            </script>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        </div>
    </div>
@endsection

