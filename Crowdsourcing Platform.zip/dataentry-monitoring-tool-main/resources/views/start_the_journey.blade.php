@extends('layouts.app')
@section('content')
    <script>
        function show(shown, hidden, third, fourth, fifth) {
            document.getElementById(shown).style.display = 'block';
            document.getElementById(hidden).style.display = 'none';
            document.getElementById(third).style.display = 'none';
            document.getElementById(fourth).style.display = 'none';
            document.getElementById(fifth).style.display = 'none';
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
            return false;
        }
    </script>
    <div class="container">
        <div class="col">
            <div class="row">
                <div class="col" style="margin-left: 300px">
                    <span class="h1 fw-semibold" style="color:#972F15;margin-left: 200px;">Start the Journey</span>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="row" style="margin-top: -40px">
                <div class="col">
                    <img src="{{ asset('images/STEP 1Y.png') }}" width="320px" height="auto" class="p-0"
                         style="margin-left: 160px" />
                    <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                         style="margin-left: -130px" />


                    <img src="{{ asset('images/STEP 2Y.png') }}" width="320px" height="auto" class="p-0"
                         style="margin-left: -130px" />
                    <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                         style="margin-left: -130px" />


                    <img src="{{ asset('images/STEP 3Y.png') }}" width="320px" height="auto" class="p-0"
                         style="margin-left: -130px" />
                    <img src="{{ asset('images/arrow.png') }}" width="150px" height="180px" class=""
                         style="margin-left: -130px" />


                    <img src="{{ asset('images/STEP 4.png') }}" width="320px" height="auto" class="p-0"
                         style="margin-left: -147px" />
                </div>
            </div>
            <div class="row">

                <div class="col fw-bold" style="margin-top: -100px;margin-left: 280px">
                    <span>Get Started</span>
                    <span style="margin-left: 120px">Create Your Profile</span>
                    <span style="margin-left: 110px">Check Your Fit</span>
                    <span style="margin-left: 110px">Start the Journey</span>
                </div>
            </div>


            {{--            PAGE 1 --}}

            <div id="Page1">
                <div class="row fw-bold fs-4" style="margin-top: 0px;text-align: center">
                    <span>Congratulations! Now you are a “SELECTED CONTRIBUTOR’ . You can start your journey</span>
                </div>

                <img src="{{ asset('images/Selected Contributor Badge.png') }}" width="500px" height="auto" class="p-0 mt-5"
                     style="align-items: center;margin-left: 400px" />



                <div class="col">
                    <div class="mt-3" style="margin-left: 165px">
                        <a href="{{ route('labelling_task_type') }}">
                            <button type="button" class="btn btn btn-lg rounded-0 mt-4"
                                    style="background-color: #972F15;color: white;margin-left: 800px">Next&nbsp;&nbsp;>>
                            </button>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection
